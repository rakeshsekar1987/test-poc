"""
ZIP Packer: bundles all reports + INDEX.xlsx + manifest.json into a ZIP.
"""
import io
import json
import zipfile
from datetime import datetime
from typing import Dict
from openpyxl import Workbook
from openpyxl.styles import PatternFill, Font, Border, Side, Alignment
from openpyxl.utils import get_column_letter
from backend.models import RunInfo, DatasetStatus


HEADER_FILL = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
HEADER_FONT = Font(color="FFFFFF", bold=True, size=11)
GREEN_FILL = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
RED_FILL = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")
YELLOW_FILL = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
GREY_FILL = PatternFill(start_color="D9D9D9", end_color="D9D9D9", fill_type="solid")
THIN_BORDER = Border(
    left=Side(style='thin'), right=Side(style='thin'),
    top=Side(style='thin'), bottom=Side(style='thin')
)


def generate_index_xlsx(run_info: RunInfo) -> bytes:
    """Generate INDEX.xlsx summarizing all datasets."""
    wb = Workbook()
    ws = wb.active
    ws.title = "INDEX"
    
    headers = [
        "Dataset", "Status", "Prev Rows", "Curr Rows",
        "Added", "Removed", "Updated", "Unchanged",
        "Prev Cols", "Curr Cols",
        "Added Cols", "Removed Cols", "Type Changes",
        "Error"
    ]
    
    for c_idx, h in enumerate(headers, 1):
        cell = ws.cell(row=1, column=c_idx, value=h)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.border = THIN_BORDER
        cell.alignment = Alignment(horizontal='center')
    
    row_idx = 2
    
    # Comparable datasets
    for name, ds in sorted(run_info.datasets.items()):
        values = [
            name, ds.status.value,
            ds.prev_row_count, ds.curr_row_count,
            ds.added_count, ds.removed_count, ds.updated_count, ds.unchanged_count,
            ds.prev_col_count, ds.curr_col_count,
            len(ds.schema_change.added_columns) if ds.schema_change else 0,
            len(ds.schema_change.removed_columns) if ds.schema_change else 0,
            len(ds.schema_change.type_changes) if ds.schema_change else 0,
            ds.error or ""
        ]
        for c_idx, val in enumerate(values, 1):
            cell = ws.cell(row=row_idx, column=c_idx, value=val)
            cell.border = THIN_BORDER
            if ds.status == DatasetStatus.DONE:
                if c_idx == 2:
                    cell.fill = GREEN_FILL
            elif ds.status == DatasetStatus.FAILED:
                if c_idx == 2:
                    cell.fill = RED_FILL
            elif ds.status == DatasetStatus.SKIPPED:
                if c_idx == 2:
                    cell.fill = GREY_FILL
        row_idx += 1
    
    # Skipped datasets
    for skip in run_info.skipped_list:
        values = [skip["name"], "skipped"] + [""] * 11 + [skip["reason"]]
        for c_idx, val in enumerate(values, 1):
            cell = ws.cell(row=row_idx, column=c_idx, value=val)
            cell.border = THIN_BORDER
            if c_idx == 2:
                cell.fill = GREY_FILL
        row_idx += 1
    
    # Auto-width
    for c_idx in range(1, len(headers) + 1):
        ws.column_dimensions[get_column_letter(c_idx)].width = 16
    ws.column_dimensions['A'].width = 30
    ws.column_dimensions['N'].width = 40
    
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf.read()


def generate_manifest(run_info: RunInfo) -> str:
    """Generate manifest.json with run metadata."""
    manifest = {
        "run_id": run_info.run_id,
        "status": run_info.status.value,
        "created_at": run_info.created_at.isoformat(),
        "completed_at": run_info.completed_at.isoformat() if run_info.completed_at else None,
        "total_datasets": run_info.total_datasets,
        "comparable_datasets": run_info.comparable_datasets,
        "skipped_datasets": run_info.skipped_datasets,
        "completed_datasets": run_info.completed_datasets,
        "failed_datasets": run_info.failed_datasets,
        "options": run_info.options,
        "datasets": {},
        "skipped": run_info.skipped_list
    }
    
    for name, ds in run_info.datasets.items():
        manifest["datasets"][name] = {
            "status": ds.status.value,
            "error": ds.error,
            "prev_rows": ds.prev_row_count,
            "curr_rows": ds.curr_row_count,
            "added": ds.added_count,
            "removed": ds.removed_count,
            "updated": ds.updated_count,
            "unchanged": ds.unchanged_count,
            "schema_drift": {
                "added_columns": ds.schema_change.added_columns if ds.schema_change else [],
                "removed_columns": ds.schema_change.removed_columns if ds.schema_change else [],
                "type_changes": ds.schema_change.type_changes if ds.schema_change else {}
            }
        }
    
    return json.dumps(manifest, indent=2, default=str)


def pack_zip(run_info: RunInfo, reports: Dict[str, bytes]) -> bytes:
    """
    Pack all reports, INDEX.xlsx, and manifest.json into a ZIP.
    
    Args:
        run_info: The run information
        reports: {dataset_name: excel_bytes}
    
    Returns:
        ZIP file bytes
    """
    buf = io.BytesIO()
    
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as zf:
        # Add per-dataset reports
        for name, report_bytes in sorted(reports.items()):
            safe_name = name.replace(".xlsx", "").replace(".xls", "")
            filename = f"{safe_name}__previous_vs_current__{run_info.run_id}.xlsx"
            zf.writestr(f"reports/{filename}", report_bytes)
        
        # Add INDEX.xlsx
        index_bytes = generate_index_xlsx(run_info)
        zf.writestr("INDEX.xlsx", index_bytes)
        
        # Add manifest.json
        manifest_json = generate_manifest(run_info)
        zf.writestr("manifest.json", manifest_json)
    
    buf.seek(0)
    return buf.read()
