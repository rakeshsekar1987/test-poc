"""
Run Store: in-memory storage for comparison runs.
Thread-safe storage and retrieval of run state.
"""
import threading
from typing import Dict, Optional
from backend.models import RunInfo


class RunStore:
    """Thread-safe in-memory store for comparison runs."""
    
    def __init__(self):
        self._runs: Dict[str, RunInfo] = {}
        self._reports: Dict[str, Dict[str, bytes]] = {}  # run_id -> {dataset_name: report_bytes}
        self._zips: Dict[str, bytes] = {}  # run_id -> zip_bytes
        self._lock = threading.Lock()
    
    def create_run(self, run_info: RunInfo) -> str:
        with self._lock:
            self._runs[run_info.run_id] = run_info
            self._reports[run_info.run_id] = {}
            return run_info.run_id
    
    def get_run(self, run_id: str) -> Optional[RunInfo]:
        with self._lock:
            return self._runs.get(run_id)
    
    def update_run(self, run_info: RunInfo):
        with self._lock:
            self._runs[run_info.run_id] = run_info
    
    def store_report(self, run_id: str, dataset_name: str, report_bytes: bytes):
        with self._lock:
            if run_id not in self._reports:
                self._reports[run_id] = {}
            self._reports[run_id][dataset_name] = report_bytes
    
    def get_report(self, run_id: str, dataset_name: str) -> Optional[bytes]:
        with self._lock:
            return self._reports.get(run_id, {}).get(dataset_name)
    
    def get_all_reports(self, run_id: str) -> Dict[str, bytes]:
        with self._lock:
            return dict(self._reports.get(run_id, {}))
    
    def store_zip(self, run_id: str, zip_bytes: bytes):
        with self._lock:
            self._zips[run_id] = zip_bytes
    
    def get_zip(self, run_id: str) -> Optional[bytes]:
        with self._lock:
            return self._zips.get(run_id)


# Singleton
_store = RunStore()


def get_store() -> RunStore:
    return _store
