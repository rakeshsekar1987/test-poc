"""
Comparer service: validates Excel files, compares datasets by PatientId
or an auto-detected composite key when PatientId alone has duplicates.
"""
import itertools
import pandas as pd
import numpy as np
import hashlib
import io
from typing import Dict, Any, List, Optional, Tuple
from backend.models import SchemaChange, DatasetResult, DatasetStatus
from backend.config import get_config


def _find_composite_key(df: pd.DataFrame, pid_col: str) -> List[str]:
    """
    Find the smallest set of columns that, combined with pid_col,
    forms a unique composite key.  Tries 1-extra-column combos first,
    then 2-column combos, up to 3.  Falls back to row index if nothing works.
    Returns the full list of key columns (always starts with pid_col).
    """
    other_cols = [c for c in df.columns if c != pid_col]

    for width in range(1, min(4, len(other_cols) + 1)):
        for combo in itertools.combinations(other_cols, width):
            key_cols = [pid_col] + list(combo)
            if not df.duplicated(subset=key_cols).any():
                return key_cols

    # Last resort: append row-index so every row is unique
    idx_col = "_RowIndex"
    df[idx_col] = range(len(df))
    return [pid_col, idx_col]


def _validate_workbook(
    file_bytes: bytes, dataset_name: str, label: str
) -> Tuple[pd.DataFrame, List[str]]:
    """
    Validate an Excel file (single worksheet, has PatientId column).
    If PatientId has duplicates, auto-detect a composite key.
    Returns (DataFrame, key_columns).
    """
    from openpyxl import load_workbook

    wb = load_workbook(io.BytesIO(file_bytes), read_only=True, data_only=True)
    sheet_names = wb.sheetnames
    wb.close()

    if len(sheet_names) == 0:
        raise ValueError(f"{label}: No worksheets found in '{dataset_name}'")
    if len(sheet_names) > 1:
        raise ValueError(
            f"{label}: Multiple worksheets not supported in '{dataset_name}' "
            f"(found {len(sheet_names)} sheets: {sheet_names})"
        )

    df = pd.read_excel(io.BytesIO(file_bytes), sheet_name=0, engine="openpyxl")
    config = get_config()

    # Normalize column names
    df.columns = [str(c).strip() for c in df.columns]

    # Find PatientId column (case-insensitive)
    col_map = {c.lower(): c for c in df.columns}
    pid_key = config.patient_id_column.lower()

    if pid_key not in col_map:
        raise ValueError(
            f"{label}: Column '{config.patient_id_column}' not found in "
            f"'{dataset_name}'. Columns: {list(df.columns)}"
        )

    actual_pid_col = col_map[pid_key]

    # Normalize PatientId to string
    df[actual_pid_col] = df[actual_pid_col].astype(str).str.strip()

    # Rename to standard name if needed
    if actual_pid_col != config.patient_id_column:
        df = df.rename(columns={actual_pid_col: config.patient_id_column})

    pid_col = config.patient_id_column

    # Check for duplicates – auto-detect composite key if needed
    if df.duplicated(subset=[pid_col]).any():
        key_cols = _find_composite_key(df, pid_col)
    else:
        key_cols = [pid_col]

    return df, key_cols


def _find_candidate_keys(df: pd.DataFrame, pid_col: str) -> List[List[str]]:
    """
    Find composite keys (PatientId + extra cols) that produce uniqueness.
    Tries single-column combos first, then 2-column combos if none found.
    Returns a list of candidate key column lists.
    """
    candidates = []
    other_cols = [c for c in df.columns if c != pid_col]

    # Try PatientId + 1 column
    for col in other_cols:
        key = [pid_col, col]
        if not df.duplicated(subset=key).any():
            candidates.append(key)

    if candidates:
        return candidates

    # Try PatientId + 2 columns
    for combo in itertools.combinations(other_cols, 2):
        key = [pid_col] + list(combo)
        if not df.duplicated(subset=key).any():
            candidates.append(key)

    return candidates


def validate_dataset(file_bytes: bytes, dataset_name: str, label: str, pid_column: str) -> Dict[str, Any]:
    """
    Lightweight validation of a single file.  Returns a dict with:
      - columns: list of column names
      - row_count: number of data rows
      - has_pid: whether pid_column exists
      - pid_unique: whether pid_column is unique
      - duplicate_count: number of duplicate pid rows
      - candidate_keys: list of [pid, col] combos that are unique (only when dups)
      - error: error string if file is unreadable
      - status: 'valid' | 'needs_key' | 'error'
    """
    from openpyxl import load_workbook

    result: Dict[str, Any] = {
        "dataset_name": dataset_name,
        "label": label,
        "columns": [],
        "row_count": 0,
        "has_pid": False,
        "pid_unique": True,
        "duplicate_count": 0,
        "candidate_keys": [],
        "error": None,
        "status": "valid",
    }

    try:
        wb = load_workbook(io.BytesIO(file_bytes), read_only=True, data_only=True)
        sheets = wb.sheetnames
        wb.close()
        if len(sheets) == 0:
            result["error"] = "No worksheets found"
            result["status"] = "error"
            return result
        if len(sheets) > 1:
            result["error"] = f"Multiple worksheets ({len(sheets)}): {sheets}"
            result["status"] = "error"
            return result
    except Exception as e:
        result["error"] = f"Cannot read file: {e}"
        result["status"] = "error"
        return result

    try:
        df = pd.read_excel(io.BytesIO(file_bytes), sheet_name=0, engine="openpyxl")
        df.columns = [str(c).strip() for c in df.columns]
        result["columns"] = list(df.columns)
        result["row_count"] = len(df)

        col_map = {c.lower(): c for c in df.columns}
        pid_key = pid_column.lower()

        if pid_key not in col_map:
            result["has_pid"] = False
            result["error"] = f"Column '{pid_column}' not found"
            result["status"] = "error"
            return result

        result["has_pid"] = True
        actual_col = col_map[pid_key]
        df[actual_col] = df[actual_col].astype(str).str.strip()

        dupes = df[actual_col].duplicated()
        if dupes.any():
            result["pid_unique"] = False
            result["duplicate_count"] = int(dupes.sum())
            candidates = _find_candidate_keys(df, actual_col)
            # Return just the extra column names (not PatientId itself)
            result["candidate_keys"] = [cols[1:] for cols in candidates]
            result["status"] = "needs_key"
        else:
            result["pid_unique"] = True
            result["status"] = "valid"
    except Exception as e:
        result["error"] = f"Validation error: {e}"
        result["status"] = "error"

    return result


def _infer_column_types(df: pd.DataFrame) -> Dict[str, str]:
    """Infer column types for schema fingerprinting."""
    types = {}
    for col in df.columns:
        dtype = df[col].dtype
        if pd.api.types.is_integer_dtype(dtype):
            types[col] = "integer"
        elif pd.api.types.is_float_dtype(dtype):
            types[col] = "float"
        elif pd.api.types.is_bool_dtype(dtype):
            types[col] = "boolean"
        elif pd.api.types.is_datetime64_any_dtype(dtype):
            types[col] = "datetime"
        else:
            types[col] = "string"
    return types


def _compute_schema_fingerprint(columns: List[str], types: Dict[str, str]) -> str:
    """Compute a hash fingerprint from sorted column names + types."""
    items = sorted([(c, types.get(c, "unknown")) for c in columns])
    raw = "|".join(f"{c}:{t}" for c, t in items)
    return hashlib.sha256(raw.encode()).hexdigest()[:16]


def _detect_schema_drift(prev_df: pd.DataFrame, curr_df: pd.DataFrame, key_cols: List[str] = None) -> SchemaChange:
    """Detect added/removed columns and type changes."""
    config = get_config()
    # Only exclude PatientId and internal synthetic columns, keep composite key data columns
    exclude = {config.patient_id_column, "_key", "_RowIndex"}
    
    prev_cols = set(prev_df.columns) - exclude
    curr_cols = set(curr_df.columns) - exclude
    
    added = sorted(curr_cols - prev_cols)
    removed = sorted(prev_cols - curr_cols)
    shared = prev_cols & curr_cols
    
    prev_types = _infer_column_types(prev_df)
    curr_types = _infer_column_types(curr_df)
    
    type_changes = {}
    for col in sorted(shared):
        if prev_types.get(col) != curr_types.get(col):
            type_changes[col] = {
                "prev_type": prev_types.get(col, "unknown"),
                "curr_type": curr_types.get(col, "unknown")
            }
    
    return SchemaChange(
        added_columns=added,
        removed_columns=removed,
        type_changes=type_changes,
        prev_fingerprint=_compute_schema_fingerprint(list(prev_cols), prev_types),
        curr_fingerprint=_compute_schema_fingerprint(list(curr_cols), curr_types)
    )


def _normalize_value(val, config):
    """Normalize a cell value for comparison."""
    if val is None or (isinstance(val, float) and np.isnan(val)):
        return "" if config.treat_null_as_empty else None
    if isinstance(val, str):
        val = val.strip() if config.normalize_strings else val
        if not config.case_sensitive_values:
            val = val.lower()
    return val


def _format_val(val) -> str:
    """Format a value for display, handling NaN/None."""
    if val is None:
        return ""
    if isinstance(val, float) and np.isnan(val):
        return ""
    return str(val)


def compare_dataset(prev_bytes: bytes, curr_bytes: bytes, dataset_name: str, user_composite_key: List[str] = None) -> DatasetResult:
    """
    Compare a single dataset (previous vs current) by PatientId or
    auto-detected/user-selected composite key.
    Returns a DatasetResult with all comparison data.
    """
    result = DatasetResult(dataset_name=dataset_name)
    config = get_config()
    pid_col = config.patient_id_column
    
    try:
        prev_df, prev_keys = _validate_workbook(prev_bytes, dataset_name, "Previous")
        curr_df, curr_keys = _validate_workbook(curr_bytes, dataset_name, "Current")
    except ValueError as e:
        result.status = DatasetStatus.FAILED
        result.error = str(e)
        return result
    
    # If user selected a composite key, use it
    if user_composite_key:
        key_cols = [pid_col] + [c for c in user_composite_key if c != pid_col]
        # Verify the key columns exist in both DataFrames
        key_cols = [c for c in key_cols if c in prev_df.columns and c in curr_df.columns]
        if not key_cols:
            key_cols = [pid_col]
    else:
        # Auto-detect: use the broader composite key from either side
        key_cols = list(dict.fromkeys(prev_keys + curr_keys))
        key_cols = [c for c in key_cols if c in prev_df.columns and c in curr_df.columns]
        if not key_cols:
            key_cols = [pid_col]

    # Re-validate that the chosen key is actually unique in both sides
    if prev_df.duplicated(subset=key_cols).any():
        key_cols = _find_composite_key(prev_df, pid_col)
    if curr_df.duplicated(subset=key_cols).any():
        key_cols_curr = _find_composite_key(curr_df, pid_col)
        key_cols = list(dict.fromkeys(key_cols + key_cols_curr))
        key_cols = [c for c in key_cols if c in prev_df.columns and c in curr_df.columns]
        if not key_cols or prev_df.duplicated(subset=key_cols).any() or curr_df.duplicated(subset=key_cols).any():
            prev_df["_RowIndex"] = range(len(prev_df))
            curr_df["_RowIndex"] = range(len(curr_df))
            key_cols = [pid_col, "_RowIndex"]

    using_composite = len(key_cols) > 1

    # Build a single string key for set operations
    def make_key(df, cols):
        if len(cols) == 1:
            return df[cols[0]]
        return df[cols].astype(str).agg("||".join, axis=1)

    prev_key_series = make_key(prev_df, key_cols)
    curr_key_series = make_key(curr_df, key_cols)

    prev_df = prev_df.copy()
    curr_df = curr_df.copy()
    prev_df["_key"] = prev_key_series
    curr_df["_key"] = curr_key_series

    # Record composite key info as a validation note
    if using_composite:
        extra_cols = [c for c in key_cols if c != pid_col and c != "_RowIndex"]
        if extra_cols:
            result.validation_issues.append(
                f"Composite key used: {' + '.join(key_cols)} (PatientId has duplicates)"
            )
        else:
            result.validation_issues.append(
                "Row-index fallback used for matching (PatientId has duplicates, no unique composite found)"
            )
    
    result.prev_row_count = len(prev_df)
    result.curr_row_count = len(curr_df)
    result.prev_col_count = len(prev_df.columns)
    result.curr_col_count = len(curr_df.columns)
    
    # Schema drift (exclude internal columns)
    schema_change = _detect_schema_drift(prev_df, curr_df, key_cols)
    result.schema_change = schema_change
    
    # Row comparison by key
    prev_ids = set(prev_df["_key"].values)
    curr_ids = set(curr_df["_key"].values)
    
    added_ids = sorted(curr_ids - prev_ids)
    removed_ids = sorted(prev_ids - curr_ids)
    common_ids = sorted(prev_ids & curr_ids)
    
    result.added_count = len(added_ids)
    result.removed_count = len(removed_ids)
    
    # Index DataFrames by key
    prev_indexed = prev_df.set_index("_key")
    curr_indexed = curr_df.set_index("_key")

    # Columns to exclude from comparison output
    # Only exclude synthetic internal columns, NOT user data columns that happen to be keys
    internal_cols = {pid_col, "_key", "_RowIndex"}
    
    # The composite key columns (other than PatientId) should still appear as data
    # but we track them so we can show them in diff rows
    composite_extra = [c for c in key_cols if c not in internal_cols]
    
    # Find shared and all data columns
    prev_data_cols = set(prev_df.columns) - internal_cols
    curr_data_cols = set(curr_df.columns) - internal_cols
    shared_cols = sorted(prev_data_cols & curr_data_cols)
    all_cols = sorted(prev_data_cols | curr_data_cols)
    
    # Track changes
    updated_ids_list = []
    column_change_counts = {}
    diff_rows = []
    added_rows_list = []
    removed_rows_list = []
    updated_rows_list = []

    # Build display key: show PatientId in the row, plus composite parts
    def row_display_id(key_val, indexed_df):
        """Extract PatientId from the indexed row for display."""
        if key_val in indexed_df.index:
            r = indexed_df.loc[key_val]
            if isinstance(r, pd.DataFrame):
                r = r.iloc[0]
            return str(r.get(pid_col, key_val)) if pid_col in indexed_df.columns else str(key_val)
        return str(key_val)
    
    # Process added rows
    for kid in added_ids:
        pid_display = row_display_id(kid, curr_indexed)
        row = {"PatientId": pid_display, "_status": "added"}
        if using_composite:
            row["_CompositeKey"] = kid
        if kid in curr_indexed.index:
            curr_row = curr_indexed.loc[kid]
            if isinstance(curr_row, pd.DataFrame):
                curr_row = curr_row.iloc[0]
            for col in all_cols:
                row[f"Curr_{col}"] = _format_val(curr_row.get(col, "")) if col in curr_indexed.columns else ""
                row[f"Prev_{col}"] = ""
        added_rows_list.append(row)
        diff_rows.append(row)
    
    # Process removed rows
    for kid in removed_ids:
        pid_display = row_display_id(kid, prev_indexed)
        row = {"PatientId": pid_display, "_status": "removed"}
        if using_composite:
            row["_CompositeKey"] = kid
        if kid in prev_indexed.index:
            prev_row = prev_indexed.loc[kid]
            if isinstance(prev_row, pd.DataFrame):
                prev_row = prev_row.iloc[0]
            for col in all_cols:
                row[f"Prev_{col}"] = _format_val(prev_row.get(col, "")) if col in prev_indexed.columns else ""
                row[f"Curr_{col}"] = ""
        removed_rows_list.append(row)
        diff_rows.append(row)
    
    # Process common rows - detect updates
    for kid in common_ids:
        pid_display = row_display_id(kid, prev_indexed)
        prev_row = prev_indexed.loc[kid]
        curr_row = curr_indexed.loc[kid]
        if isinstance(prev_row, pd.DataFrame):
            prev_row = prev_row.iloc[0]
        if isinstance(curr_row, pd.DataFrame):
            curr_row = curr_row.iloc[0]
        
        changed_cols = []
        row = {"PatientId": pid_display, "_status": "unchanged"}
        if using_composite:
            row["_CompositeKey"] = kid
        
        for col in all_cols:
            prev_val = prev_row.get(col, None) if col in prev_indexed.columns else None
            curr_val = curr_row.get(col, None) if col in curr_indexed.columns else None
            
            prev_norm = _normalize_value(prev_val, config)
            curr_norm = _normalize_value(curr_val, config)
            
            # Numeric tolerance check
            is_diff = False
            if col in shared_cols:
                try:
                    pf = float(prev_norm) if prev_norm != "" else None
                    cf = float(curr_norm) if curr_norm != "" else None
                    if pf is not None and cf is not None:
                        is_diff = abs(pf - cf) > config.numeric_tolerance
                    else:
                        is_diff = str(prev_norm) != str(curr_norm)
                except (ValueError, TypeError):
                    is_diff = str(prev_norm) != str(curr_norm)
            else:
                is_diff = True  # Column only on one side
            
            row[f"Prev_{col}"] = _format_val(prev_val)
            row[f"Curr_{col}"] = _format_val(curr_val)
            
            if is_diff:
                changed_cols.append(col)
                row[f"_changed_{col}"] = True
        
        if changed_cols:
            row["_status"] = "updated"
            row["_changed_columns"] = changed_cols
            updated_ids_list.append(pid_display)
            updated_rows_list.append(row)
            for col in changed_cols:
                column_change_counts[col] = column_change_counts.get(col, 0) + 1
        
        diff_rows.append(row)
    
    result.updated_count = len(updated_ids_list)
    result.unchanged_count = len(common_ids) - len(updated_ids_list)
    
    # Top changed columns (top 20)
    result.top_changed_columns = dict(sorted(column_change_counts.items(), key=lambda x: -x[1])[:20])
    
    # Top changed patient IDs (top 20)
    result.top_changed_patient_ids = updated_ids_list[:20]
    
    result.diff_rows = diff_rows
    result.added_rows = added_rows_list
    result.removed_rows = removed_rows_list
    result.updated_rows = updated_rows_list
    result.status = DatasetStatus.DONE
    
    return result
