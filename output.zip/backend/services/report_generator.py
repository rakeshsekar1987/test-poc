"""
Report Generator: creates per-dataset Excel reports with color-coded diffs.
"""
import io
from datetime import datetime
from typing import Dict, Any, List
from openpyxl import Workbook
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from backend.models import DatasetResult


# Color definitions
YELLOW_FILL = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")  # Updated
GREEN_FILL = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")   # Added
RED_FILL = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")     # Removed
BLUE_FILL = PatternFill(start_color="BDD7EE", end_color="BDD7EE", fill_type="solid")    # Added column
GREY_FILL = PatternFill(start_color="D9D9D9", end_color="D9D9D9", fill_type="solid")    # Removed column
HEADER_FILL = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
HEADER_FONT = Font(color="FFFFFF", bold=True, size=11)
BOLD_FONT = Font(bold=True, size=11)
THIN_BORDER = Border(
    left=Side(style='thin'),
    right=Side(style='thin'),
    top=Side(style='thin'),
    bottom=Side(style='thin')
)


def generate_dataset_report(result: DatasetResult, run_id: str) -> bytes:
    """
    Generate an Excel report for a single dataset comparison.
    Returns the Excel file as bytes.
    """
    wb = Workbook()
    
    # Sheet 1: SUMMARY
    ws_summary = wb.active
    ws_summary.title = "SUMMARY"
    _write_summary_sheet(ws_summary, result, run_id)
    
    # Sheet 2: DIFF (side-by-side)
    ws_diff = wb.create_sheet("DIFF")
    _write_diff_sheet(ws_diff, result)
    
    # Sheet 3: ADDED_ROWS
    if result.added_rows:
        ws_added = wb.create_sheet("ADDED_ROWS")
        _write_status_sheet(ws_added, result.added_rows, result, "added")
    
    # Sheet 4: REMOVED_ROWS
    if result.removed_rows:
        ws_removed = wb.create_sheet("REMOVED_ROWS")
        _write_status_sheet(ws_removed, result.removed_rows, result, "removed")
    
    # Sheet 5: UPDATED_ROWS
    if result.updated_rows:
        ws_updated = wb.create_sheet("UPDATED_ROWS")
        _write_status_sheet(ws_updated, result.updated_rows, result, "updated")
    
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf.read()


def _write_summary_sheet(ws, result: DatasetResult, run_id: str):
    """Write the SUMMARY sheet."""
    ws.column_dimensions['A'].width = 30
    ws.column_dimensions['B'].width = 50
    
    rows = [
        ("Dataset Name", result.dataset_name),
        ("Run ID", run_id),
        ("Generated At", datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")),
        ("Status", result.status.value),
        ("", ""),
        ("ROW COUNTS", ""),
        ("Previous Rows", result.prev_row_count),
        ("Current Rows", result.curr_row_count),
        ("Added Rows", result.added_count),
        ("Removed Rows", result.removed_count),
        ("Updated Rows", result.updated_count),
        ("Unchanged Rows", result.unchanged_count),
        ("", ""),
        ("COLUMN COUNTS", ""),
        ("Previous Columns", result.prev_col_count),
        ("Current Columns", result.curr_col_count),
    ]
    
    if result.schema_change:
        sc = result.schema_change
        rows.append(("", ""))
        rows.append(("SCHEMA DRIFT", ""))
        rows.append(("Added Columns", ", ".join(sc.added_columns) if sc.added_columns else "None"))
        rows.append(("Removed Columns", ", ".join(sc.removed_columns) if sc.removed_columns else "None"))
        if sc.type_changes:
            for col, change in sc.type_changes.items():
                rows.append((f"Type Change: {col}", f"{change['prev_type']} \u2192 {change['curr_type']}"))
        rows.append(("Prev Schema Fingerprint", sc.prev_fingerprint))
        rows.append(("Curr Schema Fingerprint", sc.curr_fingerprint))
    
    if result.top_changed_columns:
        rows.append(("", ""))
        rows.append(("TOP CHANGED COLUMNS", ""))
        for col, count in result.top_changed_columns.items():
            rows.append((col, f"{count} changes"))
    
    if result.validation_issues:
        rows.append(("", ""))
        rows.append(("VALIDATION ISSUES", ""))
        for issue in result.validation_issues:
            rows.append(("\u26a0", issue))
    
    if result.error:
        rows.append(("", ""))
        rows.append(("ERROR", result.error))
    
    for r_idx, (label, value) in enumerate(rows, 1):
        cell_a = ws.cell(row=r_idx, column=1, value=label)
        cell_b = ws.cell(row=r_idx, column=2, value=str(value) if value != "" else "")
        if label and label == label.upper() and label.strip():
            cell_a.font = BOLD_FONT
        cell_a.border = THIN_BORDER
        cell_b.border = THIN_BORDER


def _write_diff_sheet(ws, result: DatasetResult):
    """Write the DIFF sheet with side-by-side comparison."""
    if not result.diff_rows:
        ws.cell(row=1, column=1, value="No data to compare")
        return
    
    # Extract the base column names (without Prev_/Curr_ prefix)
    base_cols = set()
    for row in result.diff_rows:
        for key in row:
            if key.startswith("Prev_"):
                base_cols.add(key[5:])
            elif key.startswith("Curr_"):
                base_cols.add(key[5:])
    base_cols = sorted(base_cols)
    
    schema_change = result.schema_change
    added_cols_set = set(schema_change.added_columns) if schema_change else set()
    removed_cols_set = set(schema_change.removed_columns) if schema_change else set()
    
    # Build headers: PatientId, Status, then Prev_col, Curr_col pairs
    headers = ["PatientId", "Status"]
    col_idx_map = {}
    idx = 3
    for col in base_cols:
        headers.append(f"Prev_{col}")
        headers.append(f"Curr_{col}")
        col_idx_map[col] = (idx, idx + 1)
        idx += 2
    
    # Write headers
    for c_idx, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=c_idx, value=header)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.border = THIN_BORDER
        cell.alignment = Alignment(horizontal='center')
        
        # Color added/removed column headers
        base_name = header.replace("Prev_", "").replace("Curr_", "")
        if base_name in added_cols_set:
            cell.fill = BLUE_FILL
            cell.font = Font(bold=True, size=11)
        elif base_name in removed_cols_set:
            cell.fill = GREY_FILL
            cell.font = Font(bold=True, size=11)
    
    # Write data rows
    for r_idx, row_data in enumerate(result.diff_rows, 2):
        status = row_data.get("_status", "unchanged")
        pid = row_data.get("PatientId", "")
        
        # PatientId cell
        pid_cell = ws.cell(row=r_idx, column=1, value=pid)
        pid_cell.border = THIN_BORDER
        
        # Status cell
        status_cell = ws.cell(row=r_idx, column=2, value=status)
        status_cell.border = THIN_BORDER
        
        # Apply row-level fill for added/removed
        row_fill = None
        if status == "added":
            row_fill = GREEN_FILL
        elif status == "removed":
            row_fill = RED_FILL
        
        if row_fill:
            pid_cell.fill = row_fill
            status_cell.fill = row_fill
        
        # Write column values
        for col in base_cols:
            if col not in col_idx_map:
                continue
            prev_idx, curr_idx = col_idx_map[col]
            
            prev_val = row_data.get(f"Prev_{col}", "")
            curr_val = row_data.get(f"Curr_{col}", "")
            
            prev_cell = ws.cell(row=r_idx, column=prev_idx, value=prev_val)
            curr_cell = ws.cell(row=r_idx, column=curr_idx, value=curr_val)
            prev_cell.border = THIN_BORDER
            curr_cell.border = THIN_BORDER
            
            if row_fill:
                prev_cell.fill = row_fill
                curr_cell.fill = row_fill
            elif status == "updated" and row_data.get(f"_changed_{col}"):
                prev_cell.fill = YELLOW_FILL
                curr_cell.fill = YELLOW_FILL
    
    # Auto-size columns (approximate)
    for c_idx in range(1, len(headers) + 1):
        ws.column_dimensions[get_column_letter(c_idx)].width = 18


def _write_status_sheet(ws, rows: list, result: DatasetResult, status_type: str):
    """Write a sheet for a specific status type (added/removed/updated)."""
    if not rows:
        ws.cell(row=1, column=1, value=f"No {status_type} rows")
        return
    
    # Determine columns
    base_cols = set()
    for row in rows:
        for key in row:
            if key.startswith("Prev_"):
                base_cols.add(key[5:])
            elif key.startswith("Curr_"):
                base_cols.add(key[5:])
    base_cols = sorted(base_cols)
    
    # For added rows, show Curr_ columns. For removed, show Prev_. For updated, show both.
    headers = ["PatientId"]
    if status_type == "added":
        for col in base_cols:
            headers.append(col)
    elif status_type == "removed":
        for col in base_cols:
            headers.append(col)
    else:
        for col in base_cols:
            headers.append(f"Prev_{col}")
            headers.append(f"Curr_{col}")
    
    # Write headers
    for c_idx, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=c_idx, value=header)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.border = THIN_BORDER
    
    fill = GREEN_FILL if status_type == "added" else RED_FILL if status_type == "removed" else None
    
    for r_idx, row_data in enumerate(rows, 2):
        pid = row_data.get("PatientId", "")
        ws.cell(row=r_idx, column=1, value=pid).border = THIN_BORDER
        if fill:
            ws.cell(row=r_idx, column=1).fill = fill
        
        c_offset = 2
        if status_type == "added":
            for col in base_cols:
                cell = ws.cell(row=r_idx, column=c_offset, value=row_data.get(f"Curr_{col}", ""))
                cell.border = THIN_BORDER
                cell.fill = GREEN_FILL
                c_offset += 1
        elif status_type == "removed":
            for col in base_cols:
                cell = ws.cell(row=r_idx, column=c_offset, value=row_data.get(f"Prev_{col}", ""))
                cell.border = THIN_BORDER
                cell.fill = RED_FILL
                c_offset += 1
        else:
            for col in base_cols:
                prev_cell = ws.cell(row=r_idx, column=c_offset, value=row_data.get(f"Prev_{col}", ""))
                curr_cell = ws.cell(row=r_idx, column=c_offset + 1, value=row_data.get(f"Curr_{col}", ""))
                prev_cell.border = THIN_BORDER
                curr_cell.border = THIN_BORDER
                if row_data.get(f"_changed_{col}"):
                    prev_cell.fill = YELLOW_FILL
                    curr_cell.fill = YELLOW_FILL
                c_offset += 2
    
    for c_idx in range(1, len(headers) + 1):
        ws.column_dimensions[get_column_letter(c_idx)].width = 18
