"""
Scanner service: matches datasets by filename between previous and current week.
"""
import os
from typing import Dict, List, Tuple


def match_datasets(prev_files: Dict[str, bytes], curr_files: Dict[str, bytes]) -> Tuple[List[str], List[Dict[str, str]]]:
    """
    Match datasets by filename (case-insensitive).
    
    Args:
        prev_files: {normalized_filename: file_bytes}
        curr_files: {normalized_filename: file_bytes}
    
    Returns:
        (comparable_names, skipped_list)
        comparable_names: list of dataset names present in both
        skipped_list: list of {name, reason} for datasets only in one side
    """
    prev_names = {name.lower(): name for name in prev_files}
    curr_names = {name.lower(): name for name in curr_files}
    
    prev_keys = set(prev_names.keys())
    curr_keys = set(curr_names.keys())
    
    common = sorted(prev_keys & curr_keys)
    
    skipped = []
    for k in sorted(prev_keys - curr_keys):
        skipped.append({"name": prev_names[k], "reason": "Missing in current_week"})
    for k in sorted(curr_keys - prev_keys):
        skipped.append({"name": curr_names[k], "reason": "Missing in previous_week"})
    
    # Return using the original casing from previous_files for common
    comparable = [prev_names.get(k, curr_names[k]) for k in common]
    return comparable, skipped
