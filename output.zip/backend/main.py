"""
EXDC - Excel Dataset Comparator Backend
FastAPI application for comparing weekly Excel datasets.
"""
import asyncio
import io
import json
import os
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from typing import Dict, List, Optional

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response, StreamingResponse
from fastapi.staticfiles import StaticFiles

from backend.config import get_config
from backend.models import DatasetResult, DatasetStatus, RunInfo, RunStatus
from backend.services.comparer import compare_dataset, validate_dataset
from backend.services.report_generator import generate_dataset_report
from backend.services.run_store import get_store
from backend.services.scanner import match_datasets
from backend.services.zip_packer import pack_zip

app = FastAPI(title="EXDC - Excel Dataset Comparator", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount frontend static files
frontend_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "frontend")
if os.path.isdir(frontend_dir):
    app.mount("/ui", StaticFiles(directory=frontend_dir, html=True), name="frontend")


@app.get("/health")
async def health():
    return {"status": "ok", "version": "1.0.0"}


@app.post("/validate")
async def validate_files(
    previous_files: List[UploadFile] = File(...),
    current_files: List[UploadFile] = File(...),
    options: str = Form("{}"),
):
    """Validate uploaded files: check columns, detect duplicates, suggest composite keys."""
    try:
        opts = json.loads(options)
    except json.JSONDecodeError:
        opts = {}

    pid_column = opts.get("patient_id_column", "PatientId")

    prev_bytes: Dict[str, bytes] = {}
    curr_bytes: Dict[str, bytes] = {}

    for f in previous_files:
        name = f.filename or "unknown.xlsx"
        content = await f.read()
        if content:
            prev_bytes[name] = content

    for f in current_files:
        name = f.filename or "unknown.xlsx"
        content = await f.read()
        if content:
            curr_bytes[name] = content

    # Match datasets
    comparable, skipped = match_datasets(prev_bytes, curr_bytes)

    # Validate each comparable dataset (both prev and curr)
    datasets = []
    for ds_name in comparable:
        ds_key = ds_name.lower()
        prev_b = next((v for k, v in prev_bytes.items() if k.lower() == ds_key), None)
        curr_b = next((v for k, v in curr_bytes.items() if k.lower() == ds_key), None)

        prev_val = validate_dataset(prev_b, ds_name, "previous", pid_column) if prev_b else None
        curr_val = validate_dataset(curr_b, ds_name, "current", pid_column) if curr_b else None

        # Merge validation: compare columns across prev/curr
        prev_cols = set(prev_val["columns"]) if prev_val else set()
        curr_cols = set(curr_val["columns"]) if curr_val else set()
        shared_cols = sorted(prev_cols & curr_cols)
        added_cols = sorted(curr_cols - prev_cols)
        removed_cols = sorted(prev_cols - curr_cols)

        # Determine overall status
        has_error = (prev_val and prev_val["status"] == "error") or (curr_val and curr_val["status"] == "error")
        needs_key = (prev_val and prev_val["status"] == "needs_key") or (curr_val and curr_val["status"] == "needs_key")

        # Merge candidate keys from both sides
        all_candidates = []
        if prev_val and prev_val["candidate_keys"]:
            all_candidates.extend(prev_val["candidate_keys"])
        if curr_val and curr_val["candidate_keys"]:
            for ck in curr_val["candidate_keys"]:
                if ck not in all_candidates:
                    all_candidates.append(ck)
        # Only keep candidates that exist in BOTH sides
        if all_candidates:
            all_candidates = [ck for ck in all_candidates if all(c in prev_cols and c in curr_cols for c in ck)]

        if has_error:
            status = "error"
            error = (prev_val or {}).get("error") or (curr_val or {}).get("error")
        elif needs_key:
            status = "needs_key"
            error = None
        else:
            status = "valid"
            error = None

        datasets.append({
            "name": ds_name,
            "status": status,
            "error": error,
            "prev_columns": sorted(prev_cols),
            "curr_columns": sorted(curr_cols),
            "shared_columns": shared_cols,
            "added_columns": added_cols,
            "removed_columns": removed_cols,
            "columns_match": prev_cols == curr_cols,
            "prev_row_count": prev_val["row_count"] if prev_val else 0,
            "curr_row_count": curr_val["row_count"] if curr_val else 0,
            "pid_unique_prev": prev_val["pid_unique"] if prev_val else True,
            "pid_unique_curr": curr_val["pid_unique"] if curr_val else True,
            "duplicate_count_prev": prev_val["duplicate_count"] if prev_val else 0,
            "duplicate_count_curr": curr_val["duplicate_count"] if curr_val else 0,
            "candidate_keys": all_candidates,
        })

    valid_count = sum(1 for d in datasets if d["status"] == "valid")
    needs_key_count = sum(1 for d in datasets if d["status"] == "needs_key")
    error_count = sum(1 for d in datasets if d["status"] == "error")

    return {
        "total": len(comparable),
        "valid": valid_count,
        "needs_key": needs_key_count,
        "errors": error_count,
        "skipped": len(skipped),
        "skipped_list": skipped,
        "datasets": datasets,
    }


@app.post("/runs")
async def create_run(
    previous_files: List[UploadFile] = File(...),
    current_files: List[UploadFile] = File(...),
    options: str = Form("{}"),
):
    """Start a new comparison run."""
    store = get_store()

    # Parse options
    try:
        opts = json.loads(options)
    except json.JSONDecodeError:
        opts = {}

    # Apply options to config
    config = get_config()
    if "patient_id_column" in opts:
        config.patient_id_column = opts["patient_id_column"]
    if "numeric_tolerance" in opts:
        config.numeric_tolerance = float(opts["numeric_tolerance"])
    if "max_workers" in opts:
        config.max_workers = int(opts["max_workers"])

    # Read all uploaded files into memory
    prev_files: Dict[str, bytes] = {}
    curr_files: Dict[str, bytes] = {}

    for f in previous_files:
        name = f.filename or "unknown.xlsx"
        content = await f.read()
        if content:
            prev_files[name] = content

    for f in current_files:
        name = f.filename or "unknown.xlsx"
        content = await f.read()
        if content:
            curr_files[name] = content

    if not prev_files:
        raise HTTPException(status_code=400, detail="No previous_week files uploaded")
    if not curr_files:
        raise HTTPException(status_code=400, detail="No current_week files uploaded")

    # Match datasets
    comparable, skipped = match_datasets(prev_files, curr_files)

    # Create run
    run_info = RunInfo(
        status=RunStatus.RUNNING,
        total_datasets=len(comparable) + len(skipped),
        comparable_datasets=len(comparable),
        skipped_datasets=len(skipped),
        skipped_list=skipped,
        options=opts,
    )

    # Initialize dataset entries
    for name in comparable:
        run_info.datasets[name] = DatasetResult(
            dataset_name=name, status=DatasetStatus.PENDING
        )

    store.create_run(run_info)

    # Build file lookup (case-insensitive)
    prev_lookup = {k.lower(): v for k, v in prev_files.items()}
    curr_lookup = {k.lower(): v for k, v in curr_files.items()}

    # Launch background comparison
    composite_keys = opts.get("composite_keys", {})
    asyncio.get_event_loop().run_in_executor(
        None,
        _run_comparison,
        run_info.run_id,
        comparable,
        prev_lookup,
        curr_lookup,
        config.max_workers,
        composite_keys,
    )

    return {"run_id": run_info.run_id, "status": run_info.status.value}


def _run_comparison(
    run_id: str,
    comparable: List[str],
    prev_lookup: Dict[str, bytes],
    curr_lookup: Dict[str, bytes],
    max_workers: int,
    composite_keys: Dict[str, List[str]] = None,
):
    """Run dataset comparisons in parallel (executed in background thread)."""
    store = get_store()
    run_info = store.get_run(run_id)
    if not run_info:
        return

    def compare_one(dataset_name: str) -> tuple:
        """Compare a single dataset, return (name, result, report_bytes)."""
        lname = dataset_name.lower()
        prev_bytes = prev_lookup.get(lname)
        curr_bytes = curr_lookup.get(lname)

        if not prev_bytes or not curr_bytes:
            result = DatasetResult(
                dataset_name=dataset_name,
                status=DatasetStatus.FAILED,
                error="File bytes not found for comparison",
            )
            return dataset_name, result, None

        # Update status to running
        run_info.datasets[dataset_name].status = DatasetStatus.RUNNING
        store.update_run(run_info)

        try:
            user_key = (composite_keys or {}).get(dataset_name)
            result = compare_dataset(prev_bytes, curr_bytes, dataset_name, user_key)
            report_bytes = None
            if result.status == DatasetStatus.DONE:
                report_bytes = generate_dataset_report(result, run_id)
            return dataset_name, result, report_bytes
        except Exception as e:
            result = DatasetResult(
                dataset_name=dataset_name,
                status=DatasetStatus.FAILED,
                error=str(e),
            )
            return dataset_name, result, None

    completed = 0
    failed = 0

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {
            executor.submit(compare_one, name): name for name in comparable
        }

        for future in futures:
            try:
                name, result, report_bytes = future.result()
                run_info.datasets[name] = result

                if result.status == DatasetStatus.DONE:
                    completed += 1
                    if report_bytes:
                        store.store_report(run_id, name, report_bytes)
                else:
                    failed += 1
            except Exception as e:
                name = futures[future]
                run_info.datasets[name] = DatasetResult(
                    dataset_name=name,
                    status=DatasetStatus.FAILED,
                    error=f"Unexpected error: {str(e)}",
                )
                failed += 1

            run_info.completed_datasets = completed
            run_info.failed_datasets = failed
            total_done = completed + failed
            if run_info.comparable_datasets > 0:
                run_info.progress_pct = round(
                    (total_done / run_info.comparable_datasets) * 100, 1
                )
            store.update_run(run_info)

    # Generate ZIP
    try:
        all_reports = store.get_all_reports(run_id)
        zip_bytes = pack_zip(run_info, all_reports)
        store.store_zip(run_id, zip_bytes)
    except Exception as e:
        print(f"ZIP generation error: {e}")

    run_info.status = RunStatus.COMPLETED
    run_info.completed_at = datetime.utcnow()
    run_info.progress_pct = 100.0
    store.update_run(run_info)


@app.get("/runs/{run_id}")
async def get_run(run_id: str):
    """Get run status and summary."""
    store = get_store()
    run_info = store.get_run(run_id)
    if not run_info:
        raise HTTPException(status_code=404, detail="Run not found")

    # Return without heavy diff_rows for status polling
    data = run_info.model_dump()
    for ds_name in data.get("datasets", {}):
        data["datasets"][ds_name].pop("diff_rows", None)
        data["datasets"][ds_name].pop("added_rows", None)
        data["datasets"][ds_name].pop("removed_rows", None)
        data["datasets"][ds_name].pop("updated_rows", None)
    return data


@app.get("/runs/{run_id}/datasets")
async def get_datasets(run_id: str):
    """List all datasets with stats (no diff rows)."""
    store = get_store()
    run_info = store.get_run(run_id)
    if not run_info:
        raise HTTPException(status_code=404, detail="Run not found")

    result = []
    for name, ds in sorted(run_info.datasets.items()):
        ds_dict = ds.model_dump()
        ds_dict.pop("diff_rows", None)
        ds_dict.pop("added_rows", None)
        ds_dict.pop("removed_rows", None)
        ds_dict.pop("updated_rows", None)
        result.append(ds_dict)
    return result


@app.get("/runs/{run_id}/datasets/{dataset_name}")
async def get_dataset_detail(run_id: str, dataset_name: str):
    """Get detailed dataset result including diff rows."""
    store = get_store()
    run_info = store.get_run(run_id)
    if not run_info:
        raise HTTPException(status_code=404, detail="Run not found")

    ds = run_info.datasets.get(dataset_name)
    if not ds:
        raise HTTPException(status_code=404, detail="Dataset not found")

    return ds.model_dump()


@app.get("/runs/{run_id}/datasets/{dataset_name}/report")
async def download_dataset_report(run_id: str, dataset_name: str):
    """Download single dataset Excel report."""
    store = get_store()
    report_bytes = store.get_report(run_id, dataset_name)
    if not report_bytes:
        raise HTTPException(status_code=404, detail="Report not found")

    safe_name = dataset_name.replace(".xlsx", "").replace(".xls", "")
    filename = f"{safe_name}__previous_vs_current__{run_id}.xlsx"

    return Response(
        content=report_bytes,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@app.get("/runs/{run_id}/download")
async def download_zip(run_id: str):
    """Download ZIP containing all reports + INDEX + manifest."""
    store = get_store()
    zip_bytes = store.get_zip(run_id)
    if not zip_bytes:
        raise HTTPException(status_code=404, detail="ZIP not ready or run not found")

    return Response(
        content=zip_bytes,
        media_type="application/zip",
        headers={
            "Content-Disposition": f'attachment; filename="exdc_comparison_{run_id}.zip"'
        },
    )


@app.post("/runs/{run_id}/download-filtered")
async def download_filtered_zip(run_id: str, body: dict):
    """Download ZIP with reports filtered to specific PatientIds (cross data filter)."""
    store = get_store()
    run_info = store.get_run(run_id)
    if not run_info:
        raise HTTPException(status_code=404, detail="Run not found")

    patient_ids = set(str(pid) for pid in body.get("patient_ids", []))
    filter_desc = body.get("filter_description", "")
    if not patient_ids:
        raise HTTPException(status_code=400, detail="No patient_ids provided")

    # Build filtered reports for each done dataset
    filtered_reports: Dict[str, bytes] = {}
    filtered_run = run_info.model_copy(deep=True)

    for ds_name, ds in run_info.datasets.items():
        if ds.status != DatasetStatus.DONE or not ds.diff_rows:
            continue

        # Filter diff_rows to matching PatientIds
        filtered_diff = [r for r in ds.diff_rows if str(r.get("PatientId", "")) in patient_ids]
        if not filtered_diff:
            continue

        # Build filtered DatasetResult
        filtered_ds = ds.model_copy(deep=True)
        filtered_ds.diff_rows = filtered_diff
        filtered_ds.added_rows = [r for r in filtered_diff if r.get("_status") == "added"]
        filtered_ds.removed_rows = [r for r in filtered_diff if r.get("_status") == "removed"]
        filtered_ds.updated_rows = [r for r in filtered_diff if r.get("_status") == "updated"]
        filtered_ds.added_count = len(filtered_ds.added_rows)
        filtered_ds.removed_count = len(filtered_ds.removed_rows)
        filtered_ds.updated_count = len(filtered_ds.updated_rows)
        filtered_ds.unchanged_count = len([r for r in filtered_diff if r.get("_status") == "unchanged"])
        filtered_ds.validation_issues = list(ds.validation_issues or [])
        if filter_desc:
            filtered_ds.validation_issues.insert(0, f"Cross Data Filter: {filter_desc}")

        filtered_run.datasets[ds_name] = filtered_ds

        # Generate filtered report
        report_bytes = generate_dataset_report(filtered_ds, run_id)
        filtered_reports[ds_name] = report_bytes

    if not filtered_reports:
        raise HTTPException(status_code=404, detail="No datasets matched the filtered PatientIds")

    # Pack filtered ZIP
    zip_bytes = pack_zip(filtered_run, filtered_reports)

    return Response(
        content=zip_bytes,
        media_type="application/zip",
        headers={
            "Content-Disposition": f'attachment; filename="exdc_filtered_{run_id}.zip"'
        },
    )
