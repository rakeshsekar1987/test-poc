from pydantic import BaseModel, Field
from enum import Enum
from typing import Optional, Dict, List, Any
from datetime import datetime
import uuid


class DatasetStatus(str, Enum):
    """Status of a dataset comparison."""
    PENDING = "pending"
    RUNNING = "running"
    DONE = "done"
    FAILED = "failed"
    SKIPPED = "skipped"


class RunStatus(str, Enum):
    """Status of a comparison run."""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


class SchemaChange(BaseModel):
    """Schema changes between two datasets."""
    added_columns: List[str] = []
    removed_columns: List[str] = []
    type_changes: Dict[str, Dict[str, str]] = {}  # col -> {prev_type, curr_type}
    prev_fingerprint: str = ""
    curr_fingerprint: str = ""


class DatasetResult(BaseModel):
    """Result of comparing two dataset versions."""
    dataset_name: str
    status: DatasetStatus = DatasetStatus.PENDING
    error: Optional[str] = None
    prev_row_count: int = 0
    curr_row_count: int = 0
    added_count: int = 0
    removed_count: int = 0
    updated_count: int = 0
    unchanged_count: int = 0
    prev_col_count: int = 0
    curr_col_count: int = 0
    schema_change: Optional[SchemaChange] = None
    top_changed_columns: Dict[str, int] = {}
    top_changed_patient_ids: List[str] = []
    validation_issues: List[str] = []
    diff_rows: List[Dict[str, Any]] = []  # full diff data for UI paging
    added_rows: List[Dict[str, Any]] = []
    removed_rows: List[Dict[str, Any]] = []
    updated_rows: List[Dict[str, Any]] = []


class RunInfo(BaseModel):
    """Information about a comparison run."""
    run_id: str = Field(default_factory=lambda: str(uuid.uuid4())[:8])
    status: RunStatus = RunStatus.PENDING
    created_at: datetime = Field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = None
    total_datasets: int = 0
    comparable_datasets: int = 0
    skipped_datasets: int = 0
    completed_datasets: int = 0
    failed_datasets: int = 0
    datasets: Dict[str, DatasetResult] = {}
    skipped_list: List[Dict[str, str]] = []  # [{name, reason}]
    options: Dict[str, Any] = {}
    progress_pct: float = 0.0
