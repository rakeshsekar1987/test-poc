"""
E2E Test Suite for EXDC — Excel Dataset Comparator
Tests the full flow: health → upload → scan/run → poll → dashboard → detail → downloads
"""
import os
import sys
import time
import json
import requests
import zipfile
import io

BASE = "http://localhost:8000"
PREV_DIR = os.path.join(os.path.dirname(__file__), "..", "..", "previous_week")
CURR_DIR = os.path.join(os.path.dirname(__file__), "..", "..", "current_week")

passed = 0
failed = 0
errors = []

def check(name, condition, detail=""):
    global passed, failed
    if condition:
        passed += 1
        print(f"  ✅ {name}")
    else:
        failed += 1
        msg = f"  ❌ {name}" + (f" — {detail}" if detail else "")
        print(msg)
        errors.append(msg)

def section(title):
    print(f"\n{'='*60}\n  {title}\n{'='*60}")

# ─── 1. HEALTH CHECK ───
section("1. Health Check")
try:
    r = requests.get(f"{BASE}/health", timeout=5)
    check("GET /health returns 200", r.status_code == 200)
    d = r.json()
    check("Response has status=ok", d.get("status") == "ok")
    check("Response has version", "version" in d)
except Exception as e:
    check("Health endpoint reachable", False, str(e))

# ─── 2. ERROR HANDLING ───
section("2. Error Handling & Edge Cases")
try:
    r = requests.get(f"{BASE}/runs/nonexistent", timeout=5)
    check("GET /runs/nonexistent returns 404", r.status_code == 404)
except Exception as e:
    check("404 for missing run", False, str(e))

try:
    r = requests.get(f"{BASE}/runs/nonexistent/datasets/foo", timeout=5)
    check("GET missing dataset returns 404", r.status_code == 404)
except Exception as e:
    check("404 for missing dataset", False, str(e))

try:
    r = requests.get(f"{BASE}/runs/nonexistent/download", timeout=5)
    check("GET missing ZIP returns 404", r.status_code == 404)
except Exception as e:
    check("404 for missing ZIP", False, str(e))

try:
    r = requests.get(f"{BASE}/runs/nonexistent/datasets/foo/report", timeout=5)
    check("GET missing report returns 404", r.status_code == 404)
except Exception as e:
    check("404 for missing report", False, str(e))

# Empty upload
try:
    r = requests.post(f"{BASE}/runs", files={"previous_files": ("empty.xlsx", b""), "current_files": ("empty.xlsx", b"")}, timeout=10)
    check("Empty file upload returns 400", r.status_code == 400)
except Exception as e:
    check("Empty upload error handling", False, str(e))

# ─── 2b. VALIDATE ENDPOINT ───
section("2b. Validate Endpoint")

# Build file lists for validation
val_prev = []
val_curr = []
for fn in os.listdir(PREV_DIR):
    if fn.endswith(".xlsx"):
        val_prev.append(("previous_files", (fn, open(os.path.join(PREV_DIR, fn), "rb"), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")))
for fn in os.listdir(CURR_DIR):
    if fn.endswith(".xlsx"):
        val_curr.append(("current_files", (fn, open(os.path.join(CURR_DIR, fn), "rb"), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")))

val_files = val_prev + val_curr
val_files.append(("options", (None, json.dumps({"patient_id_column": "PatientId"}))))

r = requests.post(f"{BASE}/validate", files=val_files, timeout=30)
check("POST /validate returns 200", r.status_code == 200, f"Got {r.status_code}: {r.text[:200]}")

# Close file handles
for _, (_, fh, _) in val_prev + val_curr:
    fh.close()

if r.status_code == 200:
    vd = r.json()
    check("Validate has total count", "total" in vd and vd["total"] > 0)
    check("Validate has valid count", "valid" in vd)
    check("Validate has needs_key count", "needs_key" in vd)
    check("Validate has errors count", "errors" in vd)
    check("Validate has skipped count", "skipped" in vd)
    check("Validate has datasets list", isinstance(vd.get("datasets"), list))

    # Check individual dataset validation results
    val_ds = {d["name"]: d for d in vd["datasets"]}

    # demographics.xlsx should be valid (unique PatientId)
    if "demographics.xlsx" in val_ds:
        ds = val_ds["demographics.xlsx"]
        check("demographics.xlsx is valid", ds["status"] == "valid")
        check("demographics.xlsx has columns", len(ds["prev_columns"]) > 0)
        check("demographics.xlsx pid unique", ds["pid_unique_prev"] and ds["pid_unique_curr"])

    # duplicate_ids.xlsx should need a key
    if "duplicate_ids.xlsx" in val_ds:
        ds = val_ds["duplicate_ids.xlsx"]
        check("duplicate_ids.xlsx needs_key", ds["status"] == "needs_key")
        check("duplicate_ids.xlsx has candidate_keys", len(ds["candidate_keys"]) > 0)
        check("duplicate_ids.xlsx candidate includes VisitDate",
              any("VisitDate" in ck for ck in ds["candidate_keys"]),
              f"candidates: {ds['candidate_keys']}")
        check("duplicate_ids.xlsx has duplicates flagged", ds["duplicate_count_prev"] > 0 or ds["duplicate_count_curr"] > 0)

    # no_patientid.xlsx should be error
    if "no_patientid.xlsx" in val_ds:
        ds = val_ds["no_patientid.xlsx"]
        check("no_patientid.xlsx is error", ds["status"] == "error")
        check("no_patientid.xlsx has error message", ds["error"] is not None)

    # multi_sheet.xlsx should be error
    if "multi_sheet.xlsx" in val_ds:
        ds = val_ds["multi_sheet.xlsx"]
        check("multi_sheet.xlsx is error", ds["status"] == "error")

    # medications.xlsx has schema drift
    if "medications.xlsx" in val_ds:
        ds = val_ds["medications.xlsx"]
        check("medications.xlsx columns don't match", not ds["columns_match"])
        check("medications.xlsx has added_columns", len(ds["added_columns"]) > 0 or len(ds["removed_columns"]) > 0)

    # New duplicate-key datasets should all need a key
    dup_file_keys = {
        "prescriptions.xlsx": "MedicationName",
        "lab_orders.xlsx": "TestName",
        "diagnoses.xlsx": "DiagnosisCode",
        "appointments.xlsx": "AppointmentDate",
        "vitals_log.xlsx": "RecordedAt",
    }
    for fname, expected_col in dup_file_keys.items():
        if fname in val_ds:
            ds = val_ds[fname]
            check(f"{fname} needs_key", ds["status"] == "needs_key", f"Got: {ds['status']}")
            check(f"{fname} has candidate_keys", len(ds["candidate_keys"]) > 0, f"candidates: {ds.get('candidate_keys')}")
            has_expected = any(expected_col in ck for ck in ds["candidate_keys"])
            check(f"{fname} candidates include {expected_col}", has_expected, f"candidates: {ds['candidate_keys']}")

    print(f"\n  📊 Validation Summary: {vd['valid']} valid, {vd['needs_key']} needs_key, {vd['errors']} errors, {vd['skipped']} skipped")

# ─── 2c. VALIDATE → RUN with Composite Key ───
section("2c. Run with User-Selected Composite Key")

# Re-open files for a run with composite key
run_prev = []
run_curr = []
for fn in os.listdir(PREV_DIR):
    if fn.endswith(".xlsx"):
        run_prev.append(("previous_files", (fn, open(os.path.join(PREV_DIR, fn), "rb"), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")))
for fn in os.listdir(CURR_DIR):
    if fn.endswith(".xlsx"):
        run_curr.append(("current_files", (fn, open(os.path.join(CURR_DIR, fn), "rb"), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")))

# User explicitly selects VisitDate as composite key for duplicate_ids.xlsx
# Also select composite keys for all new duplicate datasets
opts_with_ck = json.dumps({
    "patient_id_column": "PatientId",
    "numeric_tolerance": 0,
    "max_workers": 4,
    "composite_keys": {
        "duplicate_ids.xlsx": ["VisitDate"],
        "prescriptions.xlsx": ["MedicationName"],
        "lab_orders.xlsx": ["TestName", "OrderDate"],
        "diagnoses.xlsx": ["DiagnosisCode"],
        "appointments.xlsx": ["AppointmentDate", "Department"],
        "vitals_log.xlsx": ["RecordedAt"],
    }
})
run_files = run_prev + run_curr
run_files.append(("options", (None, opts_with_ck)))

r = requests.post(f"{BASE}/runs", files=run_files, timeout=30)
check("POST /runs with composite key returns 200", r.status_code == 200)
run_ck = r.json()
run_id_ck = run_ck.get("run_id", "")
check("Run with CK has run_id", bool(run_id_ck))

for _, (_, fh, _) in run_prev + run_curr:
    fh.close()

# Poll to completion
for i in range(60):
    time.sleep(2)
    r = requests.get(f"{BASE}/runs/{run_id_ck}", timeout=10)
    if r.status_code != 200:
        continue
    d = r.json()
    if d.get("status") in ("completed", "failed"):
        break

check("CK run completed", d.get("status") == "completed")

# Verify duplicate_ids was processed with user key
r = requests.get(f"{BASE}/runs/{run_id_ck}/datasets/duplicate_ids.xlsx", timeout=10)
if r.status_code == 200:
    dd = r.json()
    check("CK run: duplicate_ids status=done", dd["status"] == "done")
    check("CK run: duplicate_ids added=2", dd["added_count"] == 2)
    check("CK run: duplicate_ids removed=2", dd["removed_count"] == 2)
    check("CK run: duplicate_ids updated=2", dd["updated_count"] == 2)
    vi = dd.get("validation_issues", [])
    check("CK run: composite key noted", any("Composite" in v or "composite" in v.lower() for v in vi), f"issues: {vi}")

    # CRITICAL: Verify VisitDate column appears in diff rows
    dr = dd.get("diff_rows", [])
    if dr:
        all_keys = set()
        for row in dr:
            all_keys.update(row.keys())
        has_visit_date = any("VisitDate" in k for k in all_keys)
        check("CK run: VisitDate visible in output", has_visit_date, f"keys: {sorted(all_keys)}")

# Verify all new duplicate datasets with explicit composite keys
ck_datasets_to_check = {
    "prescriptions.xlsx": ("MedicationName", 1, 1, 1),  # added, removed, updated
    "diagnoses.xlsx": ("DiagnosisCode", 1, 1, 1),
    "vitals_log.xlsx": ("RecordedAt", 1, 1, 1),
}
for ds_name, (key_col, min_add, min_rem, min_upd) in ck_datasets_to_check.items():
    r = requests.get(f"{BASE}/runs/{run_id_ck}/datasets/{ds_name}", timeout=10)
    if r.status_code == 200:
        dd = r.json()
        check(f"CK run: {ds_name} status=done", dd["status"] == "done")
        check(f"CK run: {ds_name} has adds", dd.get("added_count", 0) >= min_add, f"Got {dd.get('added_count')}")
        vi = dd.get("validation_issues", [])
        check(f"CK run: {ds_name} composite noted", any("composite" in v.lower() for v in vi), f"issues: {vi}")
        # Verify composite key column is visible
        dr = dd.get("diff_rows", [])
        if dr:
            all_keys = set()
            for row in dr:
                all_keys.update(row.keys())
            has_key_col = any(key_col in k for k in all_keys)
            check(f"CK run: {ds_name} {key_col} visible", has_key_col, f"keys: {sorted(all_keys)}")

# ─── 3. FULL COMPARISON RUN ───
section("3. Full Comparison Run (Upload → Process → Complete)")

prev_files = []
curr_files = []
for fn in os.listdir(PREV_DIR):
    if fn.endswith(".xlsx"):
        prev_files.append(("previous_files", (fn, open(os.path.join(PREV_DIR, fn), "rb"), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")))
for fn in os.listdir(CURR_DIR):
    if fn.endswith(".xlsx"):
        curr_files.append(("current_files", (fn, open(os.path.join(CURR_DIR, fn), "rb"), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")))

prev_count = len(prev_files)
curr_count = len(curr_files)
print(f"  📁 Previous week files: {prev_count}")
print(f"  📁 Current week files: {curr_count}")

options = json.dumps({"patient_id_column": "PatientId", "numeric_tolerance": 0, "max_workers": 4})
files = prev_files + curr_files
files.append(("options", (None, options)))

r = requests.post(f"{BASE}/runs", files=files, timeout=30)
check("POST /runs returns 200", r.status_code == 200, f"Got {r.status_code}: {r.text[:200]}")

run_data = r.json()
run_id = run_data.get("run_id", "")
check("Run ID returned", bool(run_id), f"Response: {run_data}")
check("Initial status is running", run_data.get("status") == "running")
print(f"  🆔 Run ID: {run_id}")

# Close file handles
for _, (_, fh, _) in prev_files + curr_files:
    fh.close()

# ─── 4. POLL UNTIL COMPLETE ───
section("4. Polling Run Progress")

max_polls = 60
poll_interval = 2
final_status = None
final_data = None

for i in range(max_polls):
    time.sleep(poll_interval)
    r = requests.get(f"{BASE}/runs/{run_id}", timeout=10)
    if r.status_code != 200:
        continue
    d = r.json()
    pct = d.get("progress_pct", 0)
    status = d.get("status", "unknown")
    comp = d.get("completed_datasets", 0)
    fail = d.get("failed_datasets", 0)
    total = d.get("comparable_datasets", 0)
    print(f"  ⏳ Poll {i+1}: {status} — {pct}% ({comp + fail}/{total})")
    if status in ("completed", "failed"):
        final_status = status
        final_data = d
        break

check("Run completed", final_status == "completed", f"Final status: {final_status}")
check("Progress reached 100%", final_data and final_data.get("progress_pct") == 100)

if final_data:
    comparable = final_data.get("comparable_datasets", 0)
    completed = final_data.get("completed_datasets", 0)
    failed_ds = final_data.get("failed_datasets", 0)
    skipped = final_data.get("skipped_datasets", 0)
    datasets = final_data.get("datasets", {})
    skipped_list = final_data.get("skipped_list", [])

    print(f"\n  📊 Summary:")
    print(f"     Comparable: {comparable}")
    print(f"     Completed:  {completed}")
    print(f"     Failed:     {failed_ds}")
    print(f"     Skipped:    {skipped}")

    check("At least 1 dataset completed", completed > 0)
    check("comparable_datasets > 0", comparable > 0)
    check("Datasets dict populated", len(datasets) > 0)

    # ─── 5. DATASET STATUS CHECKS ───
    section("5. Individual Dataset Results")

    done_datasets = []
    failed_datasets_list = []
    for name, ds in sorted(datasets.items()):
        st = ds.get("status", "unknown")
        if st == "done":
            done_datasets.append(name)
            add = ds.get("added_count", 0)
            rem = ds.get("removed_count", 0)
            upd = ds.get("updated_count", 0)
            unch = ds.get("unchanged_count", 0)
            print(f"  ✅ {name}: +{add} -{rem} ~{upd} ={unch} (prev={ds.get('prev_row_count',0)}, curr={ds.get('curr_row_count',0)})")
            check(f"{name} has row counts", ds.get("prev_row_count", 0) >= 0 and ds.get("curr_row_count", 0) >= 0)
            check(f"{name} counts consistent",
                  add + rem + upd + unch >= 0,
                  f"add={add} rem={rem} upd={upd} unch={unch}")
        elif st == "failed":
            failed_datasets_list.append(name)
            print(f"  ❌ {name}: FAILED — {ds.get('error', 'unknown')}")

    # duplicate_ids.xlsx must now succeed (composite key)
    check("duplicate_ids.xlsx completed (not failed)", "duplicate_ids.xlsx" in done_datasets,
          f"done={done_datasets}, failed={failed_datasets_list}")

    # New duplicate-key datasets must succeed too
    dup_datasets = ["prescriptions.xlsx", "lab_orders.xlsx", "diagnoses.xlsx", "appointments.xlsx", "vitals_log.xlsx"]
    for ds_name in dup_datasets:
        check(f"{ds_name} completed (not failed)", ds_name in done_datasets,
              f"done={done_datasets}, failed={failed_datasets_list}")

    # Expected failures: only multi_sheet and no_patientid
    check("Expected failures count is 2", len(failed_datasets_list) == 2,
          f"Failed: {failed_datasets_list}")

    if skipped_list:
        print(f"\n  ⏭ Skipped datasets:")
        for s in skipped_list:
            print(f"     {s.get('name', '?')}: {s.get('reason', '?')}")

    # ─── 6. DETAIL ENDPOINT ───
    section("6. Dataset Detail API")

    for name in done_datasets[:3]:
        r = requests.get(f"{BASE}/runs/{run_id}/datasets/{name}", timeout=10)
        check(f"GET detail for {name} returns 200", r.status_code == 200)
        detail = r.json()
        check(f"{name} has diff_rows", "diff_rows" in detail)
        check(f"{name} diff_rows is list", isinstance(detail.get("diff_rows"), list))
        dr = detail.get("diff_rows", [])
        if dr:
            row = dr[0]
            check(f"{name} diff row has _status", "_status" in row, f"Keys: {list(row.keys())[:10]}")
            has_prev_or_curr = any(k.startswith("Prev_") or k.startswith("Curr_") for k in row.keys())
            check(f"{name} diff row has Prev_/Curr_ columns", has_prev_or_curr)
        # Schema
        sc = detail.get("schema_change")
        if sc:
            check(f"{name} schema_change is dict", isinstance(sc, dict))

    # ─── 6b. COMPOSITE KEY VERIFICATION (duplicate_ids.xlsx) ───
    section("6b. Composite Key — duplicate_ids.xlsx")

    if "duplicate_ids.xlsx" in done_datasets:
        r = requests.get(f"{BASE}/runs/{run_id}/datasets/duplicate_ids.xlsx", timeout=10)
        check("GET detail for duplicate_ids.xlsx returns 200", r.status_code == 200)
        dd = r.json()

        check("duplicate_ids prev_row_count=7", dd.get("prev_row_count") == 7, f"Got {dd.get('prev_row_count')}")
        check("duplicate_ids curr_row_count=7", dd.get("curr_row_count") == 7, f"Got {dd.get('curr_row_count')}")

        # Expected: P001+2025-01-10 added, P005+2025-01-10 added = 2 added
        # P003+2025-01-07 removed, P004+2025-01-08 removed = 2 removed
        # P001+2025-01-08 updated (Diagnosis), P002+2025-01-07 updated (Cost) = 2 updated
        # 3 unchanged
        check("duplicate_ids added_count=2", dd.get("added_count") == 2, f"Got {dd.get('added_count')}")
        check("duplicate_ids removed_count=2", dd.get("removed_count") == 2, f"Got {dd.get('removed_count')}")
        check("duplicate_ids updated_count=2", dd.get("updated_count") == 2, f"Got {dd.get('updated_count')}")
        check("duplicate_ids unchanged_count=3", dd.get("unchanged_count") == 3, f"Got {dd.get('unchanged_count')}")

        vi = dd.get("validation_issues", [])
        check("duplicate_ids has composite key note", any("Composite key" in v or "composite" in v.lower() for v in vi),
              f"validation_issues: {vi}")

        # diff_rows = added + removed + updated + unchanged = 2+2+2+3 = 9
        dr = dd.get("diff_rows", [])
        expected_diff = dd.get("added_count",0) + dd.get("removed_count",0) + dd.get("updated_count",0) + dd.get("unchanged_count",0)
        check(f"duplicate_ids has {expected_diff} diff rows", len(dr) == expected_diff, f"Got {len(dr)}")

        # CRITICAL: Verify composite key columns appear in diff rows
        if dr:
            all_keys = set()
            for row in dr:
                all_keys.update(row.keys())
            # VisitDate is the composite key column — it must appear in output
            has_visit_date = any("VisitDate" in k for k in all_keys)
            check("duplicate_ids: VisitDate column visible in diff rows", has_visit_date,
                  f"Available keys: {sorted(all_keys)}")
    else:
        check("duplicate_ids.xlsx in done_datasets", False, "was not in done list")

    # ─── 6c. NEW DUPLICATE-KEY DATASETS ───
    section("6c. Composite Key — New Duplicate Datasets")

    # prescriptions.xlsx: composite key should be MedicationName
    if "prescriptions.xlsx" in done_datasets:
        r = requests.get(f"{BASE}/runs/{run_id}/datasets/prescriptions.xlsx", timeout=10)
        dd = r.json()
        check("prescriptions prev_row_count=6", dd.get("prev_row_count") == 6, f"Got {dd.get('prev_row_count')}")
        check("prescriptions curr_row_count=6", dd.get("curr_row_count") == 6, f"Got {dd.get('curr_row_count')}")
        vi = dd.get("validation_issues", [])
        check("prescriptions has composite key note", any("composite" in v.lower() for v in vi), f"issues: {vi}")
        dr = dd.get("diff_rows", [])
        if dr:
            all_keys = set()
            for row in dr:
                all_keys.update(row.keys())
            has_med_name = any("MedicationName" in k for k in all_keys)
            check("prescriptions: MedicationName visible in diff rows", has_med_name, f"keys: {sorted(all_keys)}")
        print(f"  📊 prescriptions: +{dd.get('added_count',0)} -{dd.get('removed_count',0)} ~{dd.get('updated_count',0)} ={dd.get('unchanged_count',0)}")

    # lab_orders.xlsx
    if "lab_orders.xlsx" in done_datasets:
        r = requests.get(f"{BASE}/runs/{run_id}/datasets/lab_orders.xlsx", timeout=10)
        dd = r.json()
        check("lab_orders prev_row_count=6", dd.get("prev_row_count") == 6, f"Got {dd.get('prev_row_count')}")
        check("lab_orders curr_row_count=7", dd.get("curr_row_count") == 7, f"Got {dd.get('curr_row_count')}")
        vi = dd.get("validation_issues", [])
        check("lab_orders has composite key note", any("composite" in v.lower() for v in vi), f"issues: {vi}")
        dr = dd.get("diff_rows", [])
        if dr:
            all_keys = set()
            for row in dr:
                all_keys.update(row.keys())
            has_test_name = any("TestName" in k for k in all_keys)
            check("lab_orders: TestName visible in diff rows", has_test_name, f"keys: {sorted(all_keys)}")
        print(f"  📊 lab_orders: +{dd.get('added_count',0)} -{dd.get('removed_count',0)} ~{dd.get('updated_count',0)} ={dd.get('unchanged_count',0)}")

    # diagnoses.xlsx
    if "diagnoses.xlsx" in done_datasets:
        r = requests.get(f"{BASE}/runs/{run_id}/datasets/diagnoses.xlsx", timeout=10)
        dd = r.json()
        check("diagnoses prev_row_count=5", dd.get("prev_row_count") == 5, f"Got {dd.get('prev_row_count')}")
        check("diagnoses curr_row_count=5", dd.get("curr_row_count") == 5, f"Got {dd.get('curr_row_count')}")
        vi = dd.get("validation_issues", [])
        check("diagnoses has composite key note", any("composite" in v.lower() for v in vi), f"issues: {vi}")
        dr = dd.get("diff_rows", [])
        if dr:
            all_keys = set()
            for row in dr:
                all_keys.update(row.keys())
            has_diag_code = any("DiagnosisCode" in k for k in all_keys)
            check("diagnoses: DiagnosisCode visible in diff rows", has_diag_code, f"keys: {sorted(all_keys)}")
        print(f"  📊 diagnoses: +{dd.get('added_count',0)} -{dd.get('removed_count',0)} ~{dd.get('updated_count',0)} ={dd.get('unchanged_count',0)}")

    # appointments.xlsx
    if "appointments.xlsx" in done_datasets:
        r = requests.get(f"{BASE}/runs/{run_id}/datasets/appointments.xlsx", timeout=10)
        dd = r.json()
        check("appointments prev_row_count=5", dd.get("prev_row_count") == 5, f"Got {dd.get('prev_row_count')}")
        check("appointments curr_row_count=5", dd.get("curr_row_count") == 5, f"Got {dd.get('curr_row_count')}")
        vi = dd.get("validation_issues", [])
        check("appointments has composite key note", any("composite" in v.lower() for v in vi), f"issues: {vi}")
        print(f"  📊 appointments: +{dd.get('added_count',0)} -{dd.get('removed_count',0)} ~{dd.get('updated_count',0)} ={dd.get('unchanged_count',0)}")

    # vitals_log.xlsx
    if "vitals_log.xlsx" in done_datasets:
        r = requests.get(f"{BASE}/runs/{run_id}/datasets/vitals_log.xlsx", timeout=10)
        dd = r.json()
        check("vitals_log prev_row_count=5", dd.get("prev_row_count") == 5, f"Got {dd.get('prev_row_count')}")
        check("vitals_log curr_row_count=5", dd.get("curr_row_count") == 5, f"Got {dd.get('curr_row_count')}")
        vi = dd.get("validation_issues", [])
        check("vitals_log has composite key note", any("composite" in v.lower() for v in vi), f"issues: {vi}")
        dr = dd.get("diff_rows", [])
        if dr:
            all_keys = set()
            for row in dr:
                all_keys.update(row.keys())
            has_recorded = any("RecordedAt" in k for k in all_keys)
            check("vitals_log: RecordedAt visible in diff rows", has_recorded, f"keys: {sorted(all_keys)}")
        print(f"  📊 vitals_log: +{dd.get('added_count',0)} -{dd.get('removed_count',0)} ~{dd.get('updated_count',0)} ={dd.get('unchanged_count',0)}")

    # ─── 7. DATASET LIST ENDPOINT ───
    section("7. Dataset List API")
    r = requests.get(f"{BASE}/runs/{run_id}/datasets", timeout=10)
    check("GET /runs/{id}/datasets returns 200", r.status_code == 200)
    ds_list = r.json()
    check("Dataset list is array", isinstance(ds_list, list))
    check("Dataset list has entries", len(ds_list) > 0)
    if ds_list:
        check("Dataset list entries have no diff_rows", "diff_rows" not in ds_list[0])

    # ─── 8. DOWNLOAD ENDPOINTS ───
    section("8. Downloads")

    # ZIP download
    r = requests.get(f"{BASE}/runs/{run_id}/download", timeout=30)
    check("GET ZIP download returns 200", r.status_code == 200, f"Got {r.status_code}")
    if r.status_code == 200:
        check("ZIP content-type correct", "zip" in r.headers.get("content-type", ""))
        check("ZIP has content-disposition", "content-disposition" in r.headers)
        check("ZIP size > 0", len(r.content) > 100)
        try:
            z = zipfile.ZipFile(io.BytesIO(r.content))
            names = z.namelist()
            check("ZIP is valid archive", True)
            check("ZIP contains files", len(names) > 0, f"Files: {names[:5]}")
            has_index = any("INDEX" in n.upper() for n in names)
            has_manifest = any("manifest" in n.lower() for n in names)
            check("ZIP contains INDEX", has_index, f"Files: {names}")
            check("ZIP contains manifest", has_manifest, f"Files: {names}")
            print(f"  📦 ZIP contents ({len(names)} files): {names[:8]}{'...' if len(names) > 8 else ''}")
            z.close()
        except Exception as e:
            check("ZIP is valid", False, str(e))

    # Individual report download
    if done_datasets:
        test_ds = done_datasets[0]
        r = requests.get(f"{BASE}/runs/{run_id}/datasets/{test_ds}/report", timeout=10)
        check(f"Download report for {test_ds} returns 200", r.status_code == 200)
        if r.status_code == 200:
            check("Report is xlsx content-type", "spreadsheet" in r.headers.get("content-type", "") or "xlsx" in r.headers.get("content-type", ""))
            check("Report size > 0", len(r.content) > 100)

# ─── 8b. FILTERED DOWNLOAD (Cross Data Filter) ───
section("8b. Filtered Download (Cross Data Filter)")
if run_id and done_datasets:
    # Get a dataset's detail to find PatientIds
    test_ds = done_datasets[0]
    r = requests.get(f"{BASE}/runs/{run_id}/datasets/{test_ds}", timeout=10)
    if r.status_code == 200:
        detail = r.json()
        pids = list(set(str(row.get("PatientId", "")) for row in (detail.get("diff_rows") or [])[:5]))
        check("Found PatientIds for filter test", len(pids) > 0, f"pids={pids}")

        if pids:
            # Test filtered download endpoint
            payload = {"patient_ids": pids, "filter_description": f"Test filter from {test_ds}"}
            r = requests.post(f"{BASE}/runs/{run_id}/download-filtered", json=payload, timeout=15)
            check("POST download-filtered returns 200", r.status_code == 200, f"got {r.status_code}")
            if r.status_code == 200:
                check("Filtered ZIP content-type", "zip" in r.headers.get("content-type", ""))
                check("Filtered ZIP size > 0", len(r.content) > 100)
                try:
                    zf = zipfile.ZipFile(io.BytesIO(r.content))
                    names = zf.namelist()
                    check("Filtered ZIP is valid archive", True)
                    check("Filtered ZIP contains reports", any("reports/" in n for n in names))
                    check("Filtered ZIP contains INDEX", any("INDEX" in n for n in names))
                    check("Filtered ZIP contains manifest", any("manifest" in n for n in names))
                    print(f"  📦 Filtered ZIP: {len(names)} files")
                except Exception as e:
                    check("Filtered ZIP is valid", False, str(e))

            # Test with empty patient_ids → should 400
            r2 = requests.post(f"{BASE}/runs/{run_id}/download-filtered", json={"patient_ids": []}, timeout=10)
            check("Empty patient_ids returns 400", r2.status_code == 400)

            # Test with non-matching patient_ids → should 404
            r3 = requests.post(f"{BASE}/runs/{run_id}/download-filtered", json={"patient_ids": ["ZZZZZ_NEVER_MATCH"]}, timeout=10)
            check("Non-matching patient_ids returns 404", r3.status_code == 404)

# ─── 9. FRONTEND STATIC FILES ───
section("9. Frontend Static Files")
try:
    r = requests.get(f"{BASE}/ui/", timeout=5)
    check("GET /ui/ serves frontend", r.status_code == 200)
    if r.status_code == 200:
        check("Frontend contains HTML", "<html" in r.text.lower())
        check("Frontend has app JS", "function" in r.text)
except Exception as e:
    check("Frontend accessible", False, str(e))

# ─── SUMMARY ───
section("TEST SUMMARY")
total = passed + failed
print(f"\n  Total:  {total}")
print(f"  Passed: {passed} ✅")
print(f"  Failed: {failed} ❌")
if errors:
    print(f"\n  Failed tests:")
    for e in errors:
        print(f"  {e}")
print()

sys.exit(0 if failed == 0 else 1)
