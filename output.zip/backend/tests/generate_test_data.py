"""
Generate test data for the Excel Dataset Comparison tool.
Creates exactly 25 previous_week + 15 current_week datasets.

15 comparable datasets (in BOTH dirs) covering all edge cases:
  1.  demographics.xlsx      - Realistic medical: add/remove/update/unchanged
  2.  medications.xlsx       - Schema drift: added + removed columns
  3.  lab_results.xlsx       - Large dataset (500+ rows), scattered changes
  4.  insurance.xlsx         - Zero changes (identical)
  5.  visits.xlsx            - Column type change (string -> numeric)
  6.  only_added.xlsx        - Only new rows in current
  7.  only_removed.xlsx      - Only removed rows in current
  8.  only_updated.xlsx      - All rows updated, same IDs
  9.  edge_cases.xlsx        - Null/empty, whitespace, precision, unicode, etc.
 10.  wide_dataset.xlsx      - 50+ columns, added + removed columns
 11.  duplicate_ids.xlsx     - Duplicate PatientIds (visits), uses composite key
 12.  no_patientid.xlsx      - VALIDATION ERROR: missing PatientId column
 13.  multi_sheet.xlsx       - VALIDATION ERROR: multiple worksheets
 14.  empty_dataset.xlsx     - Headers only, no data rows
 15.  patientid_only.xlsx    - Only PatientId column, add/remove

10 previous-only files (skipped as missing in current_week):
  allergies, procedures, immunizations, vital_signs, surgical_history,
  family_history, social_history, radiology, pathology, referrals
"""

import os
import random
import string
from datetime import datetime, timedelta

from openpyxl import Workbook
import pandas as pd
import numpy as np

# ---------------------------------------------------------------------------
# Directories (relative to this script -> repo root)
# ---------------------------------------------------------------------------
PREV_DIR = os.path.join(os.path.dirname(__file__), "..", "..", "previous_week")
CURR_DIR = os.path.join(os.path.dirname(__file__), "..", "..", "current_week")

random.seed(42)
np.random.seed(42)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

FIRST_NAMES = [
    "John", "Jane", "Alice", "Bob", "Charlie", "Diana", "Eve", "Frank",
    "Grace", "Hank", "Ivy", "Jack", "Karen", "Leo", "Mona", "Nick",
    "Olivia", "Pete", "Quinn", "Rita", "Sam", "Tina", "Uma", "Vince",
    "Wendy", "Xander", "Yara", "Zane",
]
LAST_NAMES = [
    "Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller",
    "Davis", "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez",
    "Wilson", "Anderson", "Thomas", "Taylor", "Moore", "Jackson", "Martin",
]


def ensure_dirs():
    """Create output dirs and remove any existing .xlsx files."""
    os.makedirs(PREV_DIR, exist_ok=True)
    os.makedirs(CURR_DIR, exist_ok=True)
    for d in [PREV_DIR, CURR_DIR]:
        for f in os.listdir(d):
            if f.endswith(".xlsx"):
                os.remove(os.path.join(d, f))


def save_df(df, path):
    """Save DataFrame to single-sheet Excel."""
    df.to_excel(path, index=False, engine="openpyxl")


def save_multi_sheet(path, df1, df2, sheet1="Sheet1", sheet2="Sheet2"):
    """Save workbook with 2 sheets."""
    with pd.ExcelWriter(path, engine="openpyxl") as w:
        df1.to_excel(w, index=False, sheet_name=sheet1)
        df2.to_excel(w, index=False, sheet_name=sheet2)


def rand_name():
    return f"{random.choice(FIRST_NAMES)} {random.choice(LAST_NAMES)}"


def rand_date(start_year=2020, end_year=2025):
    start = datetime(start_year, 1, 1)
    delta = (datetime(end_year, 12, 31) - start).days
    return (start + timedelta(days=random.randint(0, delta))).strftime("%Y-%m-%d")


def rand_phone():
    return f"({random.randint(200, 999)}) {random.randint(100, 999)}-{random.randint(1000, 9999)}"


def rand_email(name):
    domain = random.choice(["gmail.com", "yahoo.com", "outlook.com", "hospital.org"])
    return f"{name.lower().replace(' ', '.')}@{domain}"


def pid(n, prefix="P"):
    """Generate zero-padded PatientId like P001."""
    return f"{prefix}{n:03d}"


# ---------------------------------------------------------------------------
# Dataset generators
# ---------------------------------------------------------------------------

def gen_demographics():
    """1. demographics.xlsx – add/remove/update/unchanged (50 prev, 48 curr)."""
    n = 50
    rows = []
    for i in range(1, n + 1):
        name = rand_name()
        rows.append({
            "PatientId": pid(i),
            "Name": name,
            "DOB": rand_date(1950, 2000),
            "Gender": random.choice(["M", "F", "Other"]),
            "Address": f"{random.randint(1, 9999)} {random.choice(['Main', 'Oak', 'Elm', 'Pine'])} St",
            "Phone": rand_phone(),
            "Email": rand_email(name),
        })
    prev_df = pd.DataFrame(rows)

    # Current: remove 5 (P046-P050), add 3 (P051-P053), update 10 (P001-P010)
    curr_rows = [r.copy() for r in rows if int(r["PatientId"][1:]) <= 45]
    # update first 10
    for r in curr_rows[:10]:
        r["Phone"] = rand_phone()
        r["Address"] = f"{random.randint(1, 9999)} Updated Blvd"
    # add 3 new
    for i in range(51, 54):
        name = rand_name()
        curr_rows.append({
            "PatientId": pid(i),
            "Name": name,
            "DOB": rand_date(1960, 2005),
            "Gender": random.choice(["M", "F"]),
            "Address": f"{random.randint(1, 9999)} New Ave",
            "Phone": rand_phone(),
            "Email": rand_email(name),
        })
    curr_df = pd.DataFrame(curr_rows)

    save_df(prev_df, os.path.join(PREV_DIR, "demographics.xlsx"))
    save_df(curr_df, os.path.join(CURR_DIR, "demographics.xlsx"))


def gen_medications():
    """2. medications.xlsx – schema drift: remove OldColumn, add EndDate + Prescriber."""
    n = 30
    prev_rows = []
    for i in range(1, n + 1):
        prev_rows.append({
            "PatientId": pid(i),
            "MedicationName": random.choice(["Aspirin", "Metformin", "Lisinopril", "Atorvastatin"]),
            "Dosage": f"{random.choice([5, 10, 20, 50, 100])}mg",
            "Frequency": random.choice(["Daily", "BID", "TID", "PRN"]),
            "StartDate": rand_date(2021, 2024),
            "OldColumn": f"legacy_{i}",
        })
    prev_df = pd.DataFrame(prev_rows)

    # Current: remove P028-P030, add P031-P035, drop OldColumn, add EndDate + Prescriber
    curr_rows = []
    for r in prev_rows:
        idx = int(r["PatientId"][1:])
        if idx > 27:
            continue
        row = {k: v for k, v in r.items() if k != "OldColumn"}
        row["EndDate"] = rand_date(2024, 2025)
        row["Prescriber"] = f"Dr. {random.choice(LAST_NAMES)}"
        curr_rows.append(row)
    for i in range(31, 36):
        curr_rows.append({
            "PatientId": pid(i),
            "MedicationName": random.choice(["Omeprazole", "Amlodipine"]),
            "Dosage": f"{random.choice([10, 25])}mg",
            "Frequency": "Daily",
            "StartDate": rand_date(2024, 2025),
            "EndDate": "",
            "Prescriber": f"Dr. {random.choice(LAST_NAMES)}",
        })
    curr_df = pd.DataFrame(curr_rows)

    save_df(prev_df, os.path.join(PREV_DIR, "medications.xlsx"))
    save_df(curr_df, os.path.join(CURR_DIR, "medications.xlsx"))


def gen_lab_results():
    """3. lab_results.xlsx – large dataset (500 prev, 510 curr)."""
    tests = ["CBC", "BMP", "CMP", "Lipid Panel", "TSH", "HbA1c", "Urinalysis",
             "LFT", "PT/INR", "ESR"]
    units = ["mg/dL", "mmol/L", "g/dL", "%", "mIU/L", "cells/uL"]

    prev_rows = []
    for i in range(1, 501):
        prev_rows.append({
            "PatientId": pid(i),
            "TestName": random.choice(tests),
            "Value": round(random.uniform(0.5, 300.0), 2),
            "Unit": random.choice(units),
            "RefRange": f"{random.randint(1, 50)}-{random.randint(100, 300)}",
            "Date": rand_date(2023, 2024),
        })
    prev_df = pd.DataFrame(prev_rows)

    # Current: remove 20 (P481-P500), add 30 (P501-P530), update 50 (P001-P050)
    curr_rows = [r.copy() for r in prev_rows if int(r["PatientId"][1:]) <= 480]
    for r in curr_rows[:50]:
        r["Value"] = round(random.uniform(0.5, 300.0), 2)
        r["Date"] = rand_date(2024, 2025)
    for i in range(501, 531):
        curr_rows.append({
            "PatientId": pid(i),
            "TestName": random.choice(tests),
            "Value": round(random.uniform(0.5, 300.0), 2),
            "Unit": random.choice(units),
            "RefRange": f"{random.randint(1, 50)}-{random.randint(100, 300)}",
            "Date": rand_date(2024, 2025),
        })
    curr_df = pd.DataFrame(curr_rows)

    save_df(prev_df, os.path.join(PREV_DIR, "lab_results.xlsx"))
    save_df(curr_df, os.path.join(CURR_DIR, "lab_results.xlsx"))


def gen_insurance():
    """4. insurance.xlsx – zero changes (identical on both sides)."""
    rows = []
    for i in range(1, 21):
        rows.append({
            "PatientId": pid(i),
            "Provider": random.choice(["Aetna", "BlueCross", "Cigna", "UHC"]),
            "PolicyNumber": f"POL{random.randint(100000, 999999)}",
            "GroupNumber": f"GRP{random.randint(1000, 9999)}",
            "EffectiveDate": rand_date(2022, 2024),
        })
    df = pd.DataFrame(rows)
    save_df(df, os.path.join(PREV_DIR, "insurance.xlsx"))
    save_df(df, os.path.join(CURR_DIR, "insurance.xlsx"))


def gen_visits():
    """5. visits.xlsx – column type change (string -> numeric for VisitCost)."""
    n = 20
    prev_rows = []
    for i in range(1, n + 1):
        prev_rows.append({
            "PatientId": pid(i),
            "VisitDate": rand_date(2023, 2024),
            "Department": random.choice(["Cardiology", "Neurology", "Oncology"]),
            "VisitCost": str(random.randint(100, 5000)),  # string in prev
        })
    prev_df = pd.DataFrame(prev_rows)

    curr_rows = []
    for r in prev_rows:
        row = r.copy()
        row["VisitCost"] = int(r["VisitCost"])  # numeric in curr
        curr_rows.append(row)
    curr_df = pd.DataFrame(curr_rows)

    save_df(prev_df, os.path.join(PREV_DIR, "visits.xlsx"))
    save_df(curr_df, os.path.join(CURR_DIR, "visits.xlsx"))


def gen_only_added():
    """6. only_added.xlsx – only new rows in current (10 prev, 15 curr)."""
    rows = []
    for i in range(1, 11):
        rows.append({
            "PatientId": pid(i),
            "Condition": random.choice(["Diabetes", "Hypertension", "Asthma"]),
            "Severity": random.choice(["Mild", "Moderate", "Severe"]),
        })
    prev_df = pd.DataFrame(rows)

    curr_rows = [r.copy() for r in rows]
    for i in range(11, 16):
        curr_rows.append({
            "PatientId": pid(i),
            "Condition": random.choice(["COPD", "Heart Failure"]),
            "Severity": random.choice(["Mild", "Severe"]),
        })
    curr_df = pd.DataFrame(curr_rows)

    save_df(prev_df, os.path.join(PREV_DIR, "only_added.xlsx"))
    save_df(curr_df, os.path.join(CURR_DIR, "only_added.xlsx"))


def gen_only_removed():
    """7. only_removed.xlsx – only removed rows (15 prev, 10 curr)."""
    rows = []
    for i in range(1, 16):
        rows.append({
            "PatientId": pid(i),
            "Procedure": random.choice(["MRI", "CT Scan", "X-Ray", "Ultrasound"]),
            "Date": rand_date(2022, 2024),
        })
    prev_df = pd.DataFrame(rows)
    curr_df = pd.DataFrame(rows[:10])  # keep first 10

    save_df(prev_df, os.path.join(PREV_DIR, "only_removed.xlsx"))
    save_df(curr_df, os.path.join(CURR_DIR, "only_removed.xlsx"))


def gen_only_updated():
    """8. only_updated.xlsx – all rows updated, same IDs (10 rows)."""
    prev_rows = []
    curr_rows = []
    for i in range(1, 11):
        prev_rows.append({
            "PatientId": pid(i),
            "Name": f"OldName_{i}",
            "Age": 30 + i,
        })
        curr_rows.append({
            "PatientId": pid(i),
            "Name": f"NewName_{i}",
            "Age": 40 + i,
        })
    save_df(pd.DataFrame(prev_rows), os.path.join(PREV_DIR, "only_updated.xlsx"))
    save_df(pd.DataFrame(curr_rows), os.path.join(CURR_DIR, "only_updated.xlsx"))


def gen_edge_cases():
    """9. edge_cases.xlsx – 20 patients, each row tests a different comparison edge case."""
    # Prev and curr share same PatientIds; values differ in subtle ways.
    prev_rows = []
    curr_rows = []

    def _row(pid_val, cols_prev, cols_curr):
        p = {"PatientId": pid_val}
        c = {"PatientId": pid_val}
        p.update(cols_prev)
        c.update(cols_curr)
        prev_rows.append(p)
        curr_rows.append(c)

    # Row 1: null vs empty string
    _row("P001", {"NullCol": None, "OtherCol": "A"}, {"NullCol": "", "OtherCol": "A"})
    # Row 2: leading/trailing whitespace (trimmed → should match)
    _row("P002", {"WhitespaceCol": "  hello  ", "OtherCol": "B"}, {"WhitespaceCol": "hello", "OtherCol": "B"})
    # Row 3: numeric precision (1.0 vs 1.00 as strings)
    _row("P003", {"NumericCol": "1.0", "OtherCol": "C"}, {"NumericCol": "1.00", "OtherCol": "C"})
    # Row 4: boolean variations
    _row("P004", {"BoolCol": True, "OtherCol": "D"}, {"BoolCol": "true", "OtherCol": "D"})
    # Row 5: case difference in value (case-insensitive → should match)
    _row("P005", {"CaseCol": "Active", "OtherCol": "E"}, {"CaseCol": "active", "OtherCol": "E"})
    # Row 6: unicode – café vs cafe (should differ)
    _row("P006", {"UnicodeCol": "café", "OtherCol": "F"}, {"UnicodeCol": "cafe", "OtherCol": "F"})
    # Row 7: special chars (commas, quotes)
    _row("P007", {"SpecialCol": 'value, with "quotes"', "OtherCol": "G"},
         {"SpecialCol": 'value, with "quotes"', "OtherCol": "G"})
    # Row 8: long string (500 chars) identical
    long_str = "A" * 500
    _row("P008", {"LongCol": long_str, "OtherCol": "H"}, {"LongCol": long_str, "OtherCol": "H"})
    # Row 9: long string with 1-char difference
    _row("P009", {"LongCol": "B" * 500, "OtherCol": "I"}, {"LongCol": "B" * 499 + "X", "OtherCol": "I"})
    # Row 10: date format difference
    _row("P010", {"DateCol": "2024-01-15", "OtherCol": "J"}, {"DateCol": "2024-01-15", "OtherCol": "J"})
    # Row 11: numeric 0 vs empty
    _row("P011", {"ZeroCol": 0, "OtherCol": "K"}, {"ZeroCol": "", "OtherCol": "K"})
    # Row 12: float vs int representation
    _row("P012", {"NumCol": 42.0, "OtherCol": "L"}, {"NumCol": 42, "OtherCol": "L"})
    # Row 13: leading zero in PatientId (string "013")
    _row("P013", {"ValueCol": "test13", "OtherCol": "M"}, {"ValueCol": "test13", "OtherCol": "M"})
    # Row 14: numeric PatientId-like value but as string
    _row("P014", {"ValueCol": "test14", "OtherCol": "N"}, {"ValueCol": "TEST14_updated", "OtherCol": "N"})
    # Row 15: empty string both sides
    _row("P015", {"EmptyCol": "", "OtherCol": "O"}, {"EmptyCol": "", "OtherCol": "O"})
    # Row 16: None both sides
    _row("P016", {"NoneCol": None, "OtherCol": "P"}, {"NoneCol": None, "OtherCol": "P"})
    # Row 17: spaces-only string vs empty
    _row("P017", {"SpaceCol": "   ", "OtherCol": "Q"}, {"SpaceCol": "", "OtherCol": "Q"})
    # Row 18: newline in value
    _row("P018", {"NewlineCol": "line1\nline2", "OtherCol": "R"}, {"NewlineCol": "line1\nline2", "OtherCol": "R"})
    # Row 19: tab character
    _row("P019", {"TabCol": "col1\tcol2", "OtherCol": "S"}, {"TabCol": "col1\tcol2", "OtherCol": "S"})
    # Row 20: very large number
    _row("P020", {"BigNumCol": 99999999999999, "OtherCol": "T"},
         {"BigNumCol": 99999999999999, "OtherCol": "T"})

    # Build DataFrames – fill missing columns with None so all rows align
    all_cols = set()
    for r in prev_rows + curr_rows:
        all_cols.update(r.keys())
    all_cols = sorted(all_cols)

    for r in prev_rows:
        for c in all_cols:
            r.setdefault(c, None)
    for r in curr_rows:
        for c in all_cols:
            r.setdefault(c, None)

    prev_df = pd.DataFrame(prev_rows)[all_cols]
    curr_df = pd.DataFrame(curr_rows)[all_cols]

    save_df(prev_df, os.path.join(PREV_DIR, "edge_cases.xlsx"))
    save_df(curr_df, os.path.join(CURR_DIR, "edge_cases.xlsx"))


def gen_wide_dataset():
    """10. wide_dataset.xlsx – 50+ columns, added + removed columns."""
    n = 10
    # Prev: PatientId + 50 Metric_XX cols + OldWideCol = 52 columns
    prev_rows = []
    for i in range(1, n + 1):
        row = {"PatientId": pid(i)}
        for m in range(1, 51):
            row[f"Metric_{m:02d}"] = round(random.uniform(0, 100), 2)
        row["OldWideCol"] = f"old_{i}"
        prev_rows.append(row)
    prev_df = pd.DataFrame(prev_rows)

    # Curr: keep Metric_01..45, drop Metric_46..50 + OldWideCol, add NewWideMetric_01..05
    curr_rows = []
    for i in range(1, n + 1):
        row = {"PatientId": pid(i)}
        for m in range(1, 46):
            row[f"Metric_{m:02d}"] = prev_rows[i - 1][f"Metric_{m:02d}"]
        for m in range(1, 6):
            row[f"NewWideMetric_{m:02d}"] = round(random.uniform(0, 100), 2)
        curr_rows.append(row)
    curr_df = pd.DataFrame(curr_rows)

    save_df(prev_df, os.path.join(PREV_DIR, "wide_dataset.xlsx"))
    save_df(curr_df, os.path.join(CURR_DIR, "wide_dataset.xlsx"))


def gen_duplicate_ids():
    """11. duplicate_ids.xlsx – Patient visits with duplicate PatientIds.
    Uses composite key (PatientId + VisitDate) for comparison."""
    prev_rows = [
        {"PatientId": "P001", "VisitDate": "2025-01-06", "Doctor": "Dr. Smith", "Diagnosis": "Flu", "Cost": 150},
        {"PatientId": "P001", "VisitDate": "2025-01-08", "Doctor": "Dr. Lee", "Diagnosis": "Follow-up", "Cost": 75},
        {"PatientId": "P002", "VisitDate": "2025-01-07", "Doctor": "Dr. Smith", "Diagnosis": "Checkup", "Cost": 200},
        {"PatientId": "P002", "VisitDate": "2025-01-09", "Doctor": "Dr. Patel", "Diagnosis": "Blood Test", "Cost": 120},
        {"PatientId": "P003", "VisitDate": "2025-01-06", "Doctor": "Dr. Lee", "Diagnosis": "Headache", "Cost": 100},
        {"PatientId": "P003", "VisitDate": "2025-01-07", "Doctor": "Dr. Lee", "Diagnosis": "Migraine", "Cost": 180},
        {"PatientId": "P004", "VisitDate": "2025-01-08", "Doctor": "Dr. Patel", "Diagnosis": "Allergy", "Cost": 90},
    ]
    curr_rows = [
        {"PatientId": "P001", "VisitDate": "2025-01-06", "Doctor": "Dr. Smith", "Diagnosis": "Flu", "Cost": 150},
        {"PatientId": "P001", "VisitDate": "2025-01-08", "Doctor": "Dr. Lee", "Diagnosis": "Recovery", "Cost": 75},   # updated diagnosis
        {"PatientId": "P001", "VisitDate": "2025-01-10", "Doctor": "Dr. Smith", "Diagnosis": "Rash", "Cost": 110},     # new visit
        {"PatientId": "P002", "VisitDate": "2025-01-07", "Doctor": "Dr. Smith", "Diagnosis": "Checkup", "Cost": 210},  # updated cost
        {"PatientId": "P002", "VisitDate": "2025-01-09", "Doctor": "Dr. Patel", "Diagnosis": "Blood Test", "Cost": 120},
        {"PatientId": "P003", "VisitDate": "2025-01-06", "Doctor": "Dr. Lee", "Diagnosis": "Headache", "Cost": 100},
        # P003 2025-01-07 removed, P004 removed entirely
        {"PatientId": "P005", "VisitDate": "2025-01-10", "Doctor": "Dr. Smith", "Diagnosis": "Sprain", "Cost": 250},   # new patient
    ]
    save_df(pd.DataFrame(prev_rows), os.path.join(PREV_DIR, "duplicate_ids.xlsx"))
    save_df(pd.DataFrame(curr_rows), os.path.join(CURR_DIR, "duplicate_ids.xlsx"))


def gen_dup_prescriptions():
    """Prescriptions – duplicate PatientId, composite key: PatientId + MedicationName."""
    prev = [
        {"PatientId": "P001", "MedicationName": "Aspirin", "Dosage": "100mg", "Frequency": "Daily", "Prescriber": "Dr. Smith"},
        {"PatientId": "P001", "MedicationName": "Metformin", "Dosage": "500mg", "Frequency": "Twice daily", "Prescriber": "Dr. Lee"},
        {"PatientId": "P002", "MedicationName": "Lisinopril", "Dosage": "10mg", "Frequency": "Daily", "Prescriber": "Dr. Patel"},
        {"PatientId": "P002", "MedicationName": "Aspirin", "Dosage": "81mg", "Frequency": "Daily", "Prescriber": "Dr. Patel"},
        {"PatientId": "P003", "MedicationName": "Atorvastatin", "Dosage": "20mg", "Frequency": "Nightly", "Prescriber": "Dr. Smith"},
        {"PatientId": "P003", "MedicationName": "Aspirin", "Dosage": "100mg", "Frequency": "Daily", "Prescriber": "Dr. Lee"},
    ]
    curr = [
        {"PatientId": "P001", "MedicationName": "Aspirin", "Dosage": "150mg", "Frequency": "Daily", "Prescriber": "Dr. Smith"},  # updated dosage
        {"PatientId": "P001", "MedicationName": "Metformin", "Dosage": "500mg", "Frequency": "Twice daily", "Prescriber": "Dr. Lee"},
        {"PatientId": "P001", "MedicationName": "Omeprazole", "Dosage": "20mg", "Frequency": "Daily", "Prescriber": "Dr. Lee"},  # new
        {"PatientId": "P002", "MedicationName": "Lisinopril", "Dosage": "20mg", "Frequency": "Daily", "Prescriber": "Dr. Patel"},  # updated dosage
        {"PatientId": "P002", "MedicationName": "Aspirin", "Dosage": "81mg", "Frequency": "Daily", "Prescriber": "Dr. Patel"},
        {"PatientId": "P003", "MedicationName": "Atorvastatin", "Dosage": "20mg", "Frequency": "Nightly", "Prescriber": "Dr. Smith"},
        # P003 Aspirin removed
    ]
    save_df(pd.DataFrame(prev), os.path.join(PREV_DIR, "prescriptions.xlsx"))
    save_df(pd.DataFrame(curr), os.path.join(CURR_DIR, "prescriptions.xlsx"))


def gen_dup_lab_orders():
    """Lab orders – duplicate PatientId, composite key: PatientId + TestName + OrderDate."""
    prev = [
        {"PatientId": "P010", "TestName": "CBC", "OrderDate": "2025-01-06", "Result": "Normal", "Lab": "LabCorp"},
        {"PatientId": "P010", "TestName": "CBC", "OrderDate": "2025-01-13", "Result": "Normal", "Lab": "LabCorp"},
        {"PatientId": "P010", "TestName": "BMP", "OrderDate": "2025-01-06", "Result": "Abnormal", "Lab": "Quest"},
        {"PatientId": "P011", "TestName": "CBC", "OrderDate": "2025-01-07", "Result": "Normal", "Lab": "LabCorp"},
        {"PatientId": "P011", "TestName": "Lipid Panel", "OrderDate": "2025-01-07", "Result": "Borderline", "Lab": "Quest"},
        {"PatientId": "P012", "TestName": "HbA1c", "OrderDate": "2025-01-08", "Result": "6.5", "Lab": "LabCorp"},
    ]
    curr = [
        {"PatientId": "P010", "TestName": "CBC", "OrderDate": "2025-01-06", "Result": "Normal", "Lab": "LabCorp"},
        {"PatientId": "P010", "TestName": "CBC", "OrderDate": "2025-01-13", "Result": "Flagged", "Lab": "LabCorp"},  # updated
        {"PatientId": "P010", "TestName": "BMP", "OrderDate": "2025-01-06", "Result": "Normal", "Lab": "Quest"},  # updated
        {"PatientId": "P011", "TestName": "CBC", "OrderDate": "2025-01-07", "Result": "Normal", "Lab": "LabCorp"},
        {"PatientId": "P011", "TestName": "Lipid Panel", "OrderDate": "2025-01-07", "Result": "High", "Lab": "Quest"},  # updated
        {"PatientId": "P012", "TestName": "HbA1c", "OrderDate": "2025-01-08", "Result": "6.5", "Lab": "LabCorp"},
        {"PatientId": "P012", "TestName": "TSH", "OrderDate": "2025-01-09", "Result": "2.1", "Lab": "Quest"},  # new
    ]
    save_df(pd.DataFrame(prev), os.path.join(PREV_DIR, "lab_orders.xlsx"))
    save_df(pd.DataFrame(curr), os.path.join(CURR_DIR, "lab_orders.xlsx"))


def gen_dup_diagnoses():
    """Diagnoses – duplicate PatientId, composite key: PatientId + DiagnosisCode."""
    prev = [
        {"PatientId": "P020", "DiagnosisCode": "J06.9", "Description": "Acute URI", "DiagnosedBy": "Dr. Kim", "Severity": "Mild"},
        {"PatientId": "P020", "DiagnosisCode": "E11.9", "Description": "Type 2 Diabetes", "DiagnosedBy": "Dr. Lee", "Severity": "Moderate"},
        {"PatientId": "P021", "DiagnosisCode": "I10", "Description": "Hypertension", "DiagnosedBy": "Dr. Patel", "Severity": "Moderate"},
        {"PatientId": "P021", "DiagnosisCode": "E78.5", "Description": "Hyperlipidemia", "DiagnosedBy": "Dr. Patel", "Severity": "Mild"},
        {"PatientId": "P022", "DiagnosisCode": "M54.5", "Description": "Low Back Pain", "DiagnosedBy": "Dr. Smith", "Severity": "Moderate"},
    ]
    curr = [
        {"PatientId": "P020", "DiagnosisCode": "J06.9", "Description": "Acute URI", "DiagnosedBy": "Dr. Kim", "Severity": "Mild"},
        {"PatientId": "P020", "DiagnosisCode": "E11.9", "Description": "Type 2 Diabetes", "DiagnosedBy": "Dr. Lee", "Severity": "Severe"},  # updated
        {"PatientId": "P021", "DiagnosisCode": "I10", "Description": "Hypertension", "DiagnosedBy": "Dr. Patel", "Severity": "Moderate"},
        # P021 E78.5 removed
        {"PatientId": "P022", "DiagnosisCode": "M54.5", "Description": "Low Back Pain", "DiagnosedBy": "Dr. Smith", "Severity": "Moderate"},
        {"PatientId": "P022", "DiagnosisCode": "G43.909", "Description": "Migraine", "DiagnosedBy": "Dr. Kim", "Severity": "Moderate"},  # new
    ]
    save_df(pd.DataFrame(prev), os.path.join(PREV_DIR, "diagnoses.xlsx"))
    save_df(pd.DataFrame(curr), os.path.join(CURR_DIR, "diagnoses.xlsx"))


def gen_dup_appointments():
    """Appointments – duplicate PatientId, composite key: PatientId + AppointmentDate + Department."""
    prev = [
        {"PatientId": "P030", "AppointmentDate": "2025-01-06", "Department": "Cardiology", "Provider": "Dr. Heart", "Status": "Completed"},
        {"PatientId": "P030", "AppointmentDate": "2025-01-06", "Department": "Endocrinology", "Provider": "Dr. Sugar", "Status": "Completed"},
        {"PatientId": "P030", "AppointmentDate": "2025-01-10", "Department": "Cardiology", "Provider": "Dr. Heart", "Status": "Scheduled"},
        {"PatientId": "P031", "AppointmentDate": "2025-01-07", "Department": "Neurology", "Provider": "Dr. Brain", "Status": "Completed"},
        {"PatientId": "P031", "AppointmentDate": "2025-01-09", "Department": "Neurology", "Provider": "Dr. Brain", "Status": "Cancelled"},
    ]
    curr = [
        {"PatientId": "P030", "AppointmentDate": "2025-01-06", "Department": "Cardiology", "Provider": "Dr. Heart", "Status": "Completed"},
        {"PatientId": "P030", "AppointmentDate": "2025-01-06", "Department": "Endocrinology", "Provider": "Dr. Sugar", "Status": "Completed"},
        {"PatientId": "P030", "AppointmentDate": "2025-01-10", "Department": "Cardiology", "Provider": "Dr. Heart", "Status": "Completed"},  # updated
        {"PatientId": "P031", "AppointmentDate": "2025-01-07", "Department": "Neurology", "Provider": "Dr. Brain", "Status": "Completed"},
        # P031 cancelled appointment removed
        {"PatientId": "P032", "AppointmentDate": "2025-01-11", "Department": "Orthopedics", "Provider": "Dr. Bone", "Status": "Scheduled"},  # new patient
    ]
    save_df(pd.DataFrame(prev), os.path.join(PREV_DIR, "appointments.xlsx"))
    save_df(pd.DataFrame(curr), os.path.join(CURR_DIR, "appointments.xlsx"))


def gen_dup_vitals_log():
    """Vitals log – duplicate PatientId, composite key: PatientId + RecordedAt."""
    prev = [
        {"PatientId": "P040", "RecordedAt": "2025-01-06 08:00", "BP_Systolic": 120, "BP_Diastolic": 80, "HeartRate": 72, "Temp": 98.6},
        {"PatientId": "P040", "RecordedAt": "2025-01-06 14:00", "BP_Systolic": 125, "BP_Diastolic": 82, "HeartRate": 75, "Temp": 98.7},
        {"PatientId": "P040", "RecordedAt": "2025-01-07 08:00", "BP_Systolic": 118, "BP_Diastolic": 78, "HeartRate": 70, "Temp": 98.4},
        {"PatientId": "P041", "RecordedAt": "2025-01-06 09:00", "BP_Systolic": 140, "BP_Diastolic": 90, "HeartRate": 85, "Temp": 99.1},
        {"PatientId": "P041", "RecordedAt": "2025-01-07 09:00", "BP_Systolic": 135, "BP_Diastolic": 88, "HeartRate": 80, "Temp": 98.8},
    ]
    curr = [
        {"PatientId": "P040", "RecordedAt": "2025-01-06 08:00", "BP_Systolic": 120, "BP_Diastolic": 80, "HeartRate": 72, "Temp": 98.6},
        {"PatientId": "P040", "RecordedAt": "2025-01-06 14:00", "BP_Systolic": 130, "BP_Diastolic": 85, "HeartRate": 78, "Temp": 98.9},  # updated
        {"PatientId": "P040", "RecordedAt": "2025-01-07 08:00", "BP_Systolic": 118, "BP_Diastolic": 78, "HeartRate": 70, "Temp": 98.4},
        {"PatientId": "P040", "RecordedAt": "2025-01-08 08:00", "BP_Systolic": 122, "BP_Diastolic": 80, "HeartRate": 71, "Temp": 98.5},  # new
        {"PatientId": "P041", "RecordedAt": "2025-01-06 09:00", "BP_Systolic": 138, "BP_Diastolic": 89, "HeartRate": 82, "Temp": 98.9},  # updated
        # P041 Jan 7 removed
    ]
    save_df(pd.DataFrame(prev), os.path.join(PREV_DIR, "vitals_log.xlsx"))
    save_df(pd.DataFrame(curr), os.path.join(CURR_DIR, "vitals_log.xlsx"))


def gen_no_patientid():
    """12. no_patientid.xlsx – VALIDATION ERROR: no PatientId column.

    Uses 'SubjectId' which does NOT match PatientId case-insensitively.
    """
    rows = [
        {"SubjectId": "S001", "Name": "Alice", "Score": 95},
        {"SubjectId": "S002", "Name": "Bob", "Score": 88},
        {"SubjectId": "S003", "Name": "Charlie", "Score": 72},
    ]
    df = pd.DataFrame(rows)
    save_df(df, os.path.join(PREV_DIR, "no_patientid.xlsx"))
    save_df(df, os.path.join(CURR_DIR, "no_patientid.xlsx"))


def gen_multi_sheet():
    """13. multi_sheet.xlsx – VALIDATION ERROR: multiple worksheets in prev."""
    df1 = pd.DataFrame([
        {"PatientId": "P001", "Name": "Alice"},
        {"PatientId": "P002", "Name": "Bob"},
    ])
    df2 = pd.DataFrame([
        {"ExtraCol": "x1"},
        {"ExtraCol": "x2"},
    ])
    # Prev has 2 sheets -> validation error
    save_multi_sheet(
        os.path.join(PREV_DIR, "multi_sheet.xlsx"), df1, df2,
        sheet1="PatientData", sheet2="Metadata",
    )
    # Curr is clean single-sheet
    save_df(df1, os.path.join(CURR_DIR, "multi_sheet.xlsx"))


def gen_empty_dataset():
    """14. empty_dataset.xlsx – headers only, no data rows."""
    df = pd.DataFrame(columns=["PatientId", "Name", "Value"])
    save_df(df, os.path.join(PREV_DIR, "empty_dataset.xlsx"))
    save_df(df, os.path.join(CURR_DIR, "empty_dataset.xlsx"))


def gen_patientid_only():
    """15. patientid_only.xlsx – only PatientId column; add/remove/unchanged."""
    prev_df = pd.DataFrame({"PatientId": ["P001", "P002", "P003"]})
    curr_df = pd.DataFrame({"PatientId": ["P001", "P003", "P004"]})
    save_df(prev_df, os.path.join(PREV_DIR, "patientid_only.xlsx"))
    save_df(curr_df, os.path.join(CURR_DIR, "patientid_only.xlsx"))


def gen_prev_only_files():
    """16-25. Ten previous-only files (skipped during comparison)."""
    names = [
        "allergies", "procedures", "immunizations", "vital_signs",
        "surgical_history", "family_history", "social_history",
        "radiology", "pathology", "referrals",
    ]
    for idx, name in enumerate(names, start=1):
        n = random.randint(8, 25)
        rows = []
        for i in range(1, n + 1):
            rows.append({
                "PatientId": pid(i),
                "Description": f"{name.replace('_', ' ').title()} record {i}",
                "Date": rand_date(2022, 2024),
                "Notes": f"Auto-generated {name} note #{i}",
            })
        save_df(pd.DataFrame(rows), os.path.join(PREV_DIR, f"{name}.xlsx"))


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def generate_all():
    ensure_dirs()

    # 15 original comparable datasets
    gen_demographics()       # 1
    gen_medications()        # 2
    gen_lab_results()        # 3
    gen_insurance()          # 4
    gen_visits()             # 5
    gen_only_added()         # 6
    gen_only_removed()       # 7
    gen_only_updated()       # 8
    gen_edge_cases()         # 9
    gen_wide_dataset()       # 10
    gen_duplicate_ids()      # 11
    gen_no_patientid()       # 12
    gen_multi_sheet()        # 13
    gen_empty_dataset()      # 14
    gen_patientid_only()     # 15

    # 5 additional duplicate-key datasets (comparable)
    gen_dup_prescriptions()  # 16
    gen_dup_lab_orders()     # 17
    gen_dup_diagnoses()      # 18
    gen_dup_appointments()   # 19
    gen_dup_vitals_log()     # 20

    # 10 previous-only files
    gen_prev_only_files()    # 21-30

    # -----------------------------------------------------------------------
    # Summary
    # -----------------------------------------------------------------------
    prev_files = sorted(f for f in os.listdir(PREV_DIR) if f.endswith(".xlsx"))
    curr_files = sorted(f for f in os.listdir(CURR_DIR) if f.endswith(".xlsx"))
    prev_names = {os.path.splitext(f)[0] for f in prev_files}
    curr_names = {os.path.splitext(f)[0] for f in curr_files}
    comparable = sorted(prev_names & curr_names)
    skipped = sorted(prev_names - curr_names)

    print("=" * 65)
    print("  TEST DATA GENERATION SUMMARY")
    print("=" * 65)
    print(f"  previous_week : {len(prev_files)} files")
    print(f"  current_week  : {len(curr_files)} files")
    print(f"  comparable    : {len(comparable)} datasets")
    print(f"  skipped       : {len(skipped)} datasets (prev-only)")
    print("-" * 65)
    print("  COMPARABLE DATASETS:")
    for i, name in enumerate(comparable, 1):
        print(f"    {i:2d}. {name}.xlsx")
    print("-" * 65)
    print("  SKIPPED (previous-only):")
    for i, name in enumerate(skipped, 1):
        print(f"    {i:2d}. {name}.xlsx")
    print("-" * 65)
    print("  SCENARIO COVERAGE:")
    scenarios = [
        ("demographics",    "Realistic add/remove/update/unchanged"),
        ("medications",     "Schema drift (added + removed columns)"),
        ("lab_results",     "Large dataset (500+ rows), scattered changes"),
        ("insurance",       "Zero changes (identical)"),
        ("visits",          "Column type change (string -> numeric)"),
        ("only_added",      "Only new rows added"),
        ("only_removed",    "Only rows removed"),
        ("only_updated",    "All rows updated"),
        ("edge_cases",      "Null/empty, whitespace, precision, unicode, special chars"),
        ("wide_dataset",    "50+ columns with schema changes"),
        ("duplicate_ids",   "Duplicate PatientIds (visits), composite key"),
        ("prescriptions",   "Duplicate PatientIds, composite key: MedicationName"),
        ("lab_orders",      "Duplicate PatientIds, composite key: TestName+OrderDate"),
        ("diagnoses",       "Duplicate PatientIds, composite key: DiagnosisCode"),
        ("appointments",    "Duplicate PatientIds, composite key: AppointmentDate+Department"),
        ("vitals_log",      "Duplicate PatientIds, composite key: RecordedAt"),
        ("no_patientid",    "VALIDATION ERROR: missing PatientId column"),
        ("multi_sheet",     "VALIDATION ERROR: multiple worksheets"),
        ("empty_dataset",   "Headers only, no data rows"),
        ("patientid_only",  "Only PatientId column, add/remove"),
    ]
    for name, desc in scenarios:
        print(f"    {name:20s} -> {desc}")
    print("=" * 65)

    # Sanity checks
    assert len(prev_files) == 30, f"Expected 30 prev files, got {len(prev_files)}"
    assert len(curr_files) == 20, f"Expected 20 curr files, got {len(curr_files)}"
    assert len(comparable) == 20, f"Expected 20 comparable, got {len(comparable)}"
    assert len(skipped) == 10, f"Expected 10 skipped, got {len(skipped)}"
    print("\n  ✓ All assertions passed (30 prev, 20 curr, 20 comparable, 10 skipped)")


if __name__ == "__main__":
    try:
        generate_all()
        print("  ✓ Test data generation complete!")
    except Exception as e:
        print(f"  ✗ Error: {e}")
        import traceback
        traceback.print_exc()
