from pydantic_settings import BaseSettings


class AppConfig(BaseSettings):
    """Application configuration using Pydantic BaseSettings."""
    
    patient_id_column: str = "PatientId"
    numeric_tolerance: float = 0.0
    max_workers: int = 4
    output_dir: str = "./output"
    treat_null_as_empty: bool = True
    case_sensitive_values: bool = False
    normalize_strings: bool = True
    
    class Config:
        env_file = ".env"
        case_sensitive = False


_config_instance: AppConfig | None = None


def get_config() -> AppConfig:
    """Singleton function to get application configuration."""
    global _config_instance
    if _config_instance is None:
        _config_instance = AppConfig()
    return _config_instance
