# SSP - Excel Dataset Comparator

A local, production-ready tool for comparing weekly Excel patient datasets. Detects added/removed/updated rows by PatientId, schema drift, and generates color-coded Excel reports.

## Quick Start

### 1. Install Dependencies
```bash
cd C:\Users\ZF231ZS\Downloads\SSP
pip install -r requirements.txt
```

### 2. Generate Test Data (optional)
```bash
python -m backend.tests.generate_test_data
```
This creates 25 files in `previous_week/` and 15 files in `current_week/` covering 100+ edge cases.

### 3. Start the Backend
```bash
uvicorn backend.main:app --host 0.0.0.0 --port 8000 --reload
```

### 4. Open the Frontend
Navigate to: **http://localhost:8000/ui/**

Or serve separately:
```bash
cd frontend
python -m http.server 3000
```
Then open http://localhost:3000

## Configuration

| Config | Default | Description |
|--------|---------|-------------|
| `patient_id_column` | `PatientId` | Primary key column name |
| `numeric_tolerance` | `0.0` | Tolerance for numeric comparisons (0 = exact match) |
| `max_workers` | `4` | Concurrent dataset comparison threads |
| `treat_null_as_empty` | `true` | Treat NULL/NaN as empty string |
| `case_sensitive_values` | `false` | Case-sensitive value comparison |
| `normalize_strings` | `true` | Trim whitespace from values |

All options can be set via the UI or passed in the API `options` JSON.

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/health` | Health check |
| `POST` | `/runs` | Start comparison (multipart upload) |
| `GET` | `/runs/{runId}` | Run status & progress |
| `GET` | `/runs/{runId}/datasets` | List datasets with stats |
| `GET` | `/runs/{runId}/datasets/{name}` | Dataset detail with diff rows |
| `GET` | `/runs/{runId}/datasets/{name}/report` | Download single Excel report |
| `GET` | `/runs/{runId}/download` | Download ZIP with all reports |

## Output Format

### Per-Dataset Excel Report
- **SUMMARY** sheet: counts, schema drift, top changed columns
- **DIFF** sheet: side-by-side with color coding (yellow=updated, green=added, red=removed)
- **ADDED_ROWS**, **REMOVED_ROWS**, **UPDATED_ROWS**: filtered views

### ZIP Archive
- `reports/` — all per-dataset Excel reports
- `INDEX.xlsx` — master summary of all datasets
- `manifest.json` — run metadata and machine-readable results

## Project Structure
```
SSP/
├── backend/
│   ├── main.py              # FastAPI application
│   ├── config.py             # Configuration
│   ├── models.py             # Pydantic models
│   └── services/
│       ├── scanner.py        # Dataset matching
│       ├── comparer.py       # Comparison engine
│       ├── report_generator.py  # Excel report generation
│       ├── zip_packer.py     # ZIP packaging
│       └── run_store.py      # In-memory run storage
├── frontend/
│   └── index.html            # SPA application
├── previous_week/            # Previous week Excel files
├── current_week/             # Current week Excel files
├── output/                   # Generated reports
├── requirements.txt
└── README.md
```
