@echo off
title EXDC - Excel Dataset Comparator
echo.
echo  ======================================
echo   EXDC - Excel Dataset Comparator
echo  ======================================
echo.

:: Check Python is installed
where python >nul 2>&1
if %errorlevel% neq 0 (
    echo  [ERROR] Python is not installed or not in PATH.
    echo  Please install Python 3.10+ from https://www.python.org/downloads/
    echo  Make sure to check "Add Python to PATH" during installation.
    pause
    exit /b 1
)

:: Show Python version
for /f "tokens=*" %%i in ('python --version 2^>^&1') do set PYVER=%%i
echo  Found: %PYVER%

:: Check Python version is 3.10+
python -c "import sys; exit(0 if sys.version_info >= (3, 10) else 1)" 2>nul
if %errorlevel% neq 0 (
    echo  [ERROR] Python 3.10 or higher is required.
    pause
    exit /b 1
)

:: Navigate to script directory
cd /d "%~dp0"
echo  Working directory: %cd%
echo.

:: Install dependencies
echo  [1/3] Installing dependencies...
pip install -r requirements.txt --quiet --disable-pip-version-check
if %errorlevel% neq 0 (
    echo  [ERROR] Failed to install dependencies.
    echo  Try running: pip install -r requirements.txt
    pause
    exit /b 1
)
echo  [OK] Dependencies installed.
echo.

:: Generate test data if folders are empty
if not exist "previous_week\*.xlsx" (
    echo  [2/3] Generating sample test data...
    python backend\tests\generate_test_data.py
    if %errorlevel% neq 0 (
        echo  [WARN] Could not generate test data. You can add your own .xlsx files.
    ) else (
        echo  [OK] Sample data generated in previous_week\ and current_week\.
    )
) else (
    echo  [2/3] Dataset files found - skipping test data generation.
)
echo.

:: Start the server
echo  [3/3] Starting EXDC server...
echo.
echo  ============================================
echo   EXDC is running!
echo.
echo   Open in browser:  http://localhost:8000/ui/
echo  ============================================
echo.
echo  Press Ctrl+C to stop the server.
echo.

python -m uvicorn backend.main:app --host 0.0.0.0 --port 8000

pause
